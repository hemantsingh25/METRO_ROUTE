# How to Compile and Run MetroRoute (Windows, MinGW)

MetroRoute is **two languages in one program**:

* the four `.c` files in `backend\c_modules\` are compiled by **gcc**
* the `.cpp` files in `backend\src\` and `backend\CLI\` are compiled by **g++**
* all the object files are **linked by g++** into one `metroroute.exe`

## Requirements

MinGW-w64 (provides `gcc` and `g++`) with its `bin` folder on your `PATH`.
Check in Command Prompt:

```bat
gcc --version
g++ --version
```

Both must print a version. The project was tested with GCC 13; any reasonably modern
MinGW-w64 that supports `-std=c11` and `-std=c++11` should work.

## Quick way: `build.bat`

Open **Command Prompt** (or the VS Code terminal in *Command Prompt* mode), go to the
project folder (the one that contains `build.bat`), and run:

```bat
cd C:\path\to\MetroRoute
build.bat
metroroute.exe
```

| Command | What it does |
|---|---|
| `build.bat` | Compile everything and create `metroroute.exe` |
| `build.bat run` | Build, then start the program |
| `build.bat test` | Build, then compile and run both test programs |
| `build.bat clean` | Delete the `build` folder and `metroroute.exe` |

> In PowerShell run `.\build.bat` and `.\metroroute.exe` (PowerShell needs the `.\`).

Expected output of a successful build:

```
[1/3] Compiling C modules with gcc...
[2/3] Compiling C++ sources with g++...
[3/3] Linking metroroute.exe...

Build successful: metroroute.exe
```

## Manual commands (what `build.bat` does)

Run these from the project folder (`MetroRoute\`). They use only files that exist in
the project.

```bat
mkdir build

:: 1. C files -> gcc
gcc -std=c11 -Wall -Wextra -pedantic -O2 -c backend\c_modules\linked_list.c   -o build\linked_list.o
gcc -std=c11 -Wall -Wextra -pedantic -O2 -c backend\c_modules\queue.c         -o build\queue.o
gcc -std=c11 -Wall -Wextra -pedantic -O2 -c backend\c_modules\metro_graph.c   -o build\metro_graph.o
gcc -std=c11 -Wall -Wextra -pedantic -O2 -c backend\c_modules\shortest_path.c -o build\shortest_path.o

:: 2. C++ files -> g++
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -c backend\src\metro_station.cpp    -o build\metro_station.o
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -c backend\src\metro_network.cpp    -o build\metro_network.o
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -c backend\src\route_planner.cpp    -o build\route_planner.o
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -c backend\src\metro_route_app.cpp  -o build\metro_route_app.o
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -c backend\CLI\main.cpp             -o build\main.o

:: 3. Link everything into ONE executable (use g++ so the C++ library is added)
g++ -o metroroute.exe build\main.o build\metro_route_app.o build\metro_station.o build\metro_network.o build\route_planner.o build\linked_list.o build\queue.o build\metro_graph.o build\shortest_path.o

metroroute.exe
```

Meaning of the flags: `-c` compile only (make an object file, don't link); `-o` output
file name; `-std=c11` / `-std=c++11` language standard; `-Wall -Wextra -pedantic`
show all useful warnings (the project compiles with **zero** warnings); `-O2` optimise.

No `-I` option is needed: the headers include each other with relative paths
(for example `#include "../c_modules/metro_graph.h"`).

## Running the tests by hand

```bat
gcc -std=c11 -Wall -Wextra -pedantic -O2 -o build\test_c_modules.exe backend\tests\test_c_modules.c build\linked_list.o build\queue.o build\metro_graph.o build\shortest_path.o
g++ -std=c++11 -Wall -Wextra -pedantic -O2 -o build\test_cpp_integration.exe backend\tests\test_cpp_integration.cpp build\metro_station.o build\metro_network.o build\route_planner.o build\linked_list.o build\queue.o build\metro_graph.o build\shortest_path.o
build\test_c_modules.exe
build\test_cpp_integration.exe
```

(Run the build commands above first, so the `.o` files exist.) Each test program ends
with `--- N checks, 0 failed ---` and exit code 0 when everything passes.

## Linux / macOS

```sh
./build.sh          # build ./metroroute
./metroroute
./build.sh test     # build + run the tests
```

## VS Code

Open the `MetroRoute` folder, open a terminal (**Terminal → New Terminal**, choose
*Command Prompt*), and run `build.bat run`.

## Troubleshooting

| Message | Fix |
|---|---|
| `'gcc' is not recognized` / `gcc/g++ not found` | Install MinGW-w64 and add its `bin` folder (for example `C:\mingw64\bin`) to `PATH`; open a **new** terminal afterwards. |
| `cannot open output file metroroute.exe: Permission denied` | The program is still running or is locked by antivirus. Close it and build again. |
| `undefined reference to 'mg_create'` (or any `mg_`, `ll_`, `queue_`, `sp_` name) | A C object file is missing from the link command. Use `build.bat`, or make sure all four `build\*.o` C files are listed. |
| `No such file or directory` for a `.c`/`.cpp` file | You are not in the project folder. `cd` to the folder that contains `build.bat`. |
| Weird characters in the output | The program prints plain ASCII only; if you still see them, run `chcp 437`. |

## What to say during a compilation demo

"The C files — the graph, linked list, queue and shortest-path algorithm — are compiled
by **gcc**. The C++ files — the classes and the menu — are compiled by **g++**. Each
produces an object file. The last command links all object files into one
`metroroute.exe`; I link with g++ so the C++ standard library is included. The C++
classes call the C functions, which works because the C headers are wrapped in
`extern "C"`."
