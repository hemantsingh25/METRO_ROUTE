#!/bin/sh
# MetroRoute build script for Linux / macOS (same steps as build.bat).
#   ./build.sh          build ./metroroute
#   ./build.sh test     build, then compile and run the automated tests
#   ./build.sh clean    remove build/ and ./metroroute
set -e
cd "$(dirname "$0")"

if [ "$1" = "clean" ]; then rm -rf build metroroute; echo "Cleaned."; exit 0; fi

CFLAGS="-std=c11 -Wall -Wextra -pedantic -O2"
CXXFLAGS="-std=c++11 -Wall -Wextra -pedantic -O2"
CDIR=backend/c_modules
SDIR=backend/src
OUT=build
C_OBJS="$OUT/linked_list.o $OUT/queue.o $OUT/metro_graph.o $OUT/shortest_path.o"
OOP_OBJS="$OUT/metro_station.o $OUT/metro_network.o $OUT/route_planner.o"

mkdir -p "$OUT"

echo "[1/3] Compiling C modules with gcc..."
for f in linked_list queue metro_graph shortest_path; do
    gcc $CFLAGS -c "$CDIR/$f.c" -o "$OUT/$f.o"
done

echo "[2/3] Compiling C++ sources with g++..."
for f in metro_station metro_network route_planner metro_route_app; do
    g++ $CXXFLAGS -c "$SDIR/$f.cpp" -o "$OUT/$f.o"
done
g++ $CXXFLAGS -c backend/CLI/main.cpp -o "$OUT/main.o"

echo "[3/3] Linking metroroute..."
g++ -o metroroute "$OUT/main.o" "$OUT/metro_route_app.o" $OOP_OBJS $C_OBJS
echo "Build successful: ./metroroute"

if [ "$1" = "test" ]; then
    gcc $CFLAGS -o "$OUT/test_c_modules" backend/tests/test_c_modules.c $C_OBJS
    g++ $CXXFLAGS -o "$OUT/test_cpp_integration" backend/tests/test_cpp_integration.cpp $OOP_OBJS $C_OBJS
    "$OUT/test_c_modules"
    "$OUT/test_cpp_integration"
    echo "ALL TESTS PASSED"
fi
