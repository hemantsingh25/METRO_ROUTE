# MetroRoute — Viva Preparation Guide

## 1. The project in 30 seconds

> "MetroRoute models a metro network as a weighted graph and finds the best route
> between two stations. The **data structures and algorithms** — graph, linked list,
> queue, Dijkstra, BFS — are written in **C**. The **application and object-oriented
> design** — classes, inheritance, polymorphism — are written in **C++**. The C++ classes
> call the C functions through a small C API, and everything is linked into one program."

Numbers worth remembering: **20 stations, 21 connections**, 4 C modules, 4 C++ classes
+ a strategy hierarchy, build = gcc + g++ + link.

## 2. Part A — C data structures

**Q1. What data structure represents the metro?**
A weighted, undirected **graph**. Stations are vertices, connections are edges, travel
time is the weight.

**Q2. Adjacency list or matrix? Why?**
Adjacency list. The metro is *sparse* (about 2 connections per station), so a 20×20
matrix would be almost empty. The list needs **O(V + E)** space; a matrix needs O(V²).

**Q3. Where is the linked list in the project?**
Each station owns a singly linked list; **each node is one connection**
(`destination`, `travel_time`, `next`). So the linked list *is* the adjacency list.
Appending is O(1) because the list keeps a `tail` pointer; walking it is how Dijkstra
and BFS visit neighbours.

**Q4. Why is a connection stored twice?**
The metro is two-way. `mg_add_connection(A, B, t)` adds B to A's list *and* A to B's list.

**Q5. How does the queue work, and where is it used?**
A FIFO queue stored in a **circular array** (`front`, `count`, `capacity`). Index of the
back = `(front + count) % capacity`. When full, it doubles with `realloc` and re-aligns
the wrapped part. BFS uses it to visit stations in rings (1 stop away, 2 stops away, …).

**Q6. Why a circular array and not shifting elements?**
Shifting everything on each dequeue would cost O(n); with `front` moving around the
array, both enqueue and dequeue are O(1).

**Q7. What is the priority queue in Dijkstra?**
A **binary min-heap** (array-based, `heap_push`/`heap_pop` with sift-up/sift-down). It
always gives the station with the smallest distance in O(log n). It is private to
`shortest_path.c`. I use *lazy deletion*: when a shorter distance is found I push a new
entry, and outdated entries are skipped when popped (`if (visited[u]) continue;`).

**Q8. Which dynamic-memory functions did you use?**
`malloc` (list nodes, arrays), `calloc` (graph struct and `visited[]` — zero-filled),
`realloc` (growing the station array, queue, heap), `free` (cleanup everywhere).

**Q9. How do you avoid memory leaks in C?**
Every allocation has an owner and a matching free: `mg_destroy` frees every list
(`ll_clear`), then the station array, then the graph; algorithms free their temporary
arrays at a single `cleanup:` label, so every error path frees too. `realloc` results go
into a temporary pointer first so a failure doesn't lose the old block. Verified with
AddressSanitizer + LeakSanitizer.

**Q10. What is an opaque pointer?**
`typedef struct MetroGraph MetroGraph;` in the header — users know the type exists but not
its fields, so they can only use the `mg_*` functions. It hides implementation details.

## 3. Part B — Algorithms

**Q11. Explain Dijkstra on this project.**
`dist[]` = ∞ except source = 0; `parent[]` = −1; heap holds `(distance, station)`. Pop the
closest unvisited station `u`, mark it visited, and for each neighbour `v` try
`dist[u] + time < dist[v]`; if better, update `dist[v]`, `parent[v] = u` and push.
Stop when the destination is popped. Rebuild the route by following `parent[]` from the
destination back to the source and reversing.

**Q12. Why can't we use BFS for the fastest route?**
BFS counts *edges*; our edges have different times. BFS finds the fewest stops, not the
least time. That's why the project has both options.

**Q13. Why does Dijkstra fail with negative weights?**
It assumes that once a station is visited its distance is final; a negative edge could
later shorten it. Our times are always positive (`mg_add_connection` rejects ≤ 0).

**Q14. Complexity?**
Dijkstra **O((V + E) log V)**, BFS **O(V + E)**, space O(V + E). Name lookup is O(V)
(linear search) — fine for 20 stations.

**Q15. How do you handle an unreachable station?**
`dist[destination]` stays ∞ → `sp_dijkstra` returns `SP_ERR_NO_PATH` → C++ turns it into
`RouteStatus::NoRoute` → the app prints "No route found…". The shipped network is fully
connected, so I tested this with a station that has no connections.

**Q16. What if the BFS finds two routes with the same number of stops?**
It keeps the faster one (if a station is reached again from the same level with a smaller
time, its parent is updated). Otherwise the "fewest stops" option could return a slower
route for no reason — I found this by comparing against the original program and fixed it.

**Q17. How did you check correctness?**
I compared my Dijkstra and BFS with an independent algorithm (**Floyd–Warshall**) for all
400 station pairs, and compared every route, stop count and time with the original C++
program for all 380 pairs (380/380 identical).

## 4. Part C — C++ OOP

**Q18. Which classes are there and what does each do?**
`MetroStation` (a station's data), `MetroNetwork` (owns the C graph), `RouteStrategy` and
its two children (route-finding methods), `RoutePlanner` (validates names, uses a
strategy), `RouteResult` (the answer), `MetroRouteApp` (menu).

**Q19. Encapsulation example?**
Members are `private`. `MetroNetwork` keeps the C pointer private; you can only add
stations through `addStation`, which validates input. `RouteResult` has only getters.

**Q20. Constructor and destructor — what do they do here?**
`MetroNetwork()` calls `mg_create()`; `~MetroNetwork()` calls `mg_destroy()`. So the C
memory lives exactly as long as the C++ object (**RAII**) and is freed even if an
exception happens.

**Q21. Why is the copy constructor deleted?**
If two `MetroNetwork` objects shared one `MetroGraph*`, both destructors would free it —
a **double free**. Copying is forbidden; **moving** is allowed (the old object's pointer
is set to NULL, and `mg_destroy(NULL)` is safe).

**Q22. Where is inheritance?**
`FastestRouteStrategy` and `FewestStopsStrategy` inherit from the abstract class
`RouteStrategy`. They share one interface (`findRoute`, `getName`).

**Q23. Where is polymorphism?**
`RoutePlanner` holds `std::unique_ptr<RouteStrategy>` and calls
`strategy_->findRoute(...)`. Which code runs — Dijkstra or BFS — depends on the *actual
object* at run time, because `findRoute` is `virtual`. Menu option 3 puts a
`FastestRouteStrategy` there, option 4 a `FewestStopsStrategy`.

**Q24. Why a virtual destructor in the base class?**
The strategy is deleted through a base-class pointer; without `virtual ~RouteStrategy()`
the derived destructor would not run (undefined behaviour).

**Q25. Abstraction?**
The app calls `planner.planRoute("A", "B")` and gets a `RouteResult`. It doesn't know
about arrays, heaps, error codes or `malloc`.

**Q26. Why exceptions in `MetroNetwork` but a status enum in `RoutePlanner`?**
A bad station while *building* the network is a programming error → exception. A wrong
station name typed by the *user* is normal → returned as `RouteStatus::SourceNotFound`
and printed politely.

## 5. Part D — C and C++ integration

**Q27. How do C++ and C code work together?**
The C code is compiled by gcc into object files; the C++ code by g++. C++ includes the C
headers. Because those headers are wrapped in `extern "C"`, g++ doesn't mangle the names,
and the linker connects `mg_add_station` called in C++ to the function compiled in C.
All objects are linked together into `metroroute.exe`.

**Q28. What is name mangling and why `extern "C"`?**
C++ encodes parameter types into function names (to allow overloading); C doesn't. Without
`extern "C"`, g++ would look for a mangled name that gcc never created →
*undefined reference* at link time.

**Q29. Who frees the memory that crosses the boundary?**
`MetroGraph`: the `MetroNetwork` destructor. `PathResult.stations` (allocated by C): the
C++ `PathGuard` object calls `sp_free_result` in its destructor, even on exceptions. Name
strings returned by `mg_station_name` belong to the graph and are copied into
`std::string` at once.

**Q30. How do errors cross the boundary?**
C returns negative integer codes (`MG_ERR_*`, `SP_ERR_*`) because C has no exceptions. C++
converts them to exceptions or to `RouteStatus`.

**Q31. Why link with g++ and not gcc?**
g++ automatically adds the C++ standard library (`libstdc++`) that the C++ objects need.

**Q32. Does the C code use any C++ features?**
No — no classes, references, `new`/`delete`, `std::vector` or `std::string`. It compiles
with `gcc -std=c11 -pedantic` without warnings.

## 6. Part E — Practical questions

**Q33. What happens if I type an invalid station?** "Error: Source station 'X' not found!" — `RoutePlanner` checks both names before any algorithm runs.

**Q34. Same source and destination?** "You are already at the destination!" (`RouteStatus::SameStation`).

**Q35. What if I type letters in the menu?** "Invalid choice! Please enter 1-5." and the menu appears again. (The original program looped forever here — fixed.)

**Q36. How would you add a new station or connection?** In `MetroRouteApp::loadDefaultNetwork()` call `network_.addStation("Name")` and `network_.addConnection("A", "B", minutes)`.

**Q37. How would you add a new route type (e.g. "fewest line changes")?** Write a new class deriving from `RouteStrategy`, override `getName()` and `findRoute()`, and add a menu option — no change to `RoutePlanner`. (Open/closed principle.)

**Q38. What are the limitations?** Fictional data, console only, no fares or interchange time, O(V) name lookup, stations hard-coded.

**Q39. How did you test it?** Two test programs (`build.bat test`): C tests for list, queue, graph, algorithms (cross-checked with Floyd–Warshall) and C++ tests for classes and polymorphism, plus sanitizer runs for memory errors. Results are in `backend/tests/TEST_RESULTS.txt`.

## 7. Quick diagram to draw on the board

```
User -> MetroRouteApp -> RoutePlanner -> RouteStrategy*  (virtual findRoute)
                             |                  |  Fastest  -> sp_dijkstra()      -+
                             v                  |  FewestStops -> sp_fewest_stops() -+--> C layer
                        MetroNetwork  --------- mg_* functions ---------------------+   (graph + linked lists,
                      (owns MetroGraph*)                                                 queue, min-heap)
                                          <------- PathResult (ids, time) <------------+
User <- route, stops, minutes <- RouteResult
```
