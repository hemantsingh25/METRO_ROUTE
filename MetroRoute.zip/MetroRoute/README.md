# MetroRoute — Smart Metro Navigation System

A console application that finds the best route between metro stations.
**Data structures and algorithms are written in C; the application and its
object-oriented design are written in C++.** Both languages are compiled
separately and linked into one program, `metroroute.exe`.

Built as a B.Tech CSE PBL project (Data Structures + OOP).

---

## 1. Objective and features

Model a metro network as a **weighted graph** and answer the question
*"What is the best way to get from station A to station B?"*

| # | Feature |
|---|---------|
| 1 | View all 20 stations |
| 2 | View the whole network (every station with its neighbours and travel times) |
| 3 | **Shortest route (least time)** – Dijkstra's algorithm *(original feature)* |
| 4 | **Route with fewest stops** – Breadth-First Search *(new)* |
| 5 | Full route in order, total stops, total time, algorithm used |
| 6 | Input validation: unknown stations, same source/destination, disconnected stations, bad menu input |
| 7 | Unlimited searches without restarting |
| 8 | Station names are case-insensitive and extra spaces are ignored (`  isbt ` works) |

---

## 2. Architecture

```mermaid
flowchart TD
    U([User]) -->|menu choice, station names| APP

    subgraph CPP["C++ layer  (g++)  -  Object-Oriented"]
        APP["MetroRouteApp<br/>menu + input/output"]
        PLAN["RoutePlanner<br/>validates names, picks strategy"]
        STRAT["RouteStrategy (abstract)<br/>FastestRouteStrategy | FewestStopsStrategy"]
        NET["MetroNetwork<br/>RAII wrapper that owns the C graph"]
        STN["MetroStation<br/>value object"]
        APP --> PLAN --> STRAT
        APP --> NET
        PLAN --> NET
        NET --> STN
    end

    subgraph C["C layer  (gcc)  -  Data Structures and Algorithms"]
        API{{"extern C boundary<br/>plain C functions + opaque pointer"}}
        G["metro_graph.c<br/>adjacency-list graph"]
        L["linked_list.c<br/>list of connections"]
        Q["queue.c<br/>circular queue"]
        S["shortest_path.c<br/>Dijkstra + min-heap, BFS"]
        API --> G --> L
        API --> S
        S --> Q
        S --> G
    end

    NET -->|mg_add_station, mg_add_connection ...| API
    STRAT -->|sp_dijkstra / sp_fewest_stops| API
    API -->|PathResult: ids, time| STRAT
    STRAT -->|RouteResult| PLAN -->|RouteResult| APP
    APP -->|route, stops, minutes| U
```

**Reading the diagram:** the user only ever talks to `MetroRouteApp`. The app
asks the `RoutePlanner` for a route; the planner delegates to a *strategy*
object, which calls a **C function**. The C function returns a plain
`PathResult` (array of station ids + total time). The C++ code immediately
copies it into safe C++ types (`std::vector`, `RouteResult`) and frees the C
memory. Nothing outside the strategy classes ever sees a C pointer.

### How C and C++ talk to each other

1. Every C header is wrapped in `#ifdef __cplusplus / extern "C" { ... }`.
   This tells `g++` *"don't mangle these names, they are C functions"*, so the
   linker can match `mg_add_station` called from C++ with the one compiled by `gcc`.
2. The C graph is an **opaque type**: the header only says
   `typedef struct MetroGraph MetroGraph;`. C++ holds a `MetroGraph*` but cannot
   look inside it — it must use the `mg_*` functions.
3. **Errors** cross the boundary as integer codes (`MG_ERR_DUPLICATE`,
   `SP_ERR_NO_PATH`, ...). The C++ layer turns them into exceptions
   (`MetroNetwork`) or into a `RouteStatus` value (`RoutePlanner`).
4. **Ownership rules** (who frees what):

   | C resource | Created by | Freed by |
   |---|---|---|
   | `MetroGraph` | `MetroNetwork` constructor (`mg_create`) | `MetroNetwork` destructor (`mg_destroy`) |
   | `PathResult.stations` | the C algorithm | the C++ `PathGuard` object (`sp_free_result`), automatically, even if an exception occurs |
   | station-name strings returned by `mg_station_name` | owned by the graph | never freed by the caller (copied into `std::string` immediately) |

5. Build: `.c` files → **gcc**, `.cpp` files → **g++**, linked by **g++** (which
   adds the C++ standard library) into one executable.

---

## 3. Project structure and the role of each file

```
MetroRoute/
├── README.md              this file
├── COMPILATION_GUIDE.md   exact build/run steps
├── VIVA_GUIDE.md          questions and answers for the viva
├── build.bat              Windows build script (MinGW)
├── build.sh               same script for Linux/macOS
└── backend/
    ├── c_modules/                    <- DATA STRUCTURES & ALGORITHMS (pure C)
    │   ├── linked_list.h/.c          singly linked list = one station's adjacency list
    │   ├── queue.h/.c                circular-array FIFO queue (used by BFS)
    │   ├── metro_graph.h/.c          weighted undirected graph (adjacency list)
    │   └── shortest_path.h/.c        Dijkstra (min-heap) and BFS
    ├── include/                      <- C++ headers
    │   ├── metro_station.h           MetroStation (+ Connection struct)
    │   ├── metro_network.hpp         MetroNetwork (RAII wrapper of the C graph)
    │   ├── route_planner.hpp         RouteResult, RouteStrategy and derived classes, RoutePlanner
    │   └── metro_route_app.hpp       MetroRouteApp (menu)
    ├── src/                          <- C++ implementations
    │   ├── metro_station.cpp
    │   ├── metro_network.cpp
    │   ├── route_planner.cpp
    │   └── metro_route_app.cpp       also contains the 20-station network data
    ├── CLI/main.cpp                  entry point (creates MetroRouteApp, calls run())
    └── tests/
        ├── test_c_modules.c          tests for the C code
        ├── test_cpp_integration.cpp  tests for the C++ classes calling the C code
        └── TEST_RESULTS.txt          real output of the test runs
```

| File | What it does (one line for the viva) |
|---|---|
| `linked_list.c` | Insert at tail (O(1)), search, remove, free all nodes. |
| `queue.c` | Enqueue/dequeue in O(1); doubles its array with `realloc` when full. |
| `metro_graph.c` | Array of stations, each with its own linked list of neighbours; validates every input. |
| `shortest_path.c` | Dijkstra with a binary heap; BFS with the queue; builds the route from a `parent[]` array. |
| `metro_station.cpp` | A station's id, name and connections, with getters. |
| `metro_network.cpp` | Wraps the C graph: constructor creates it, destructor frees it, converts C error codes to exceptions. |
| `route_planner.cpp` | Strategy classes that call the C algorithms; planner that validates names. |
| `metro_route_app.cpp` | Menu loop, input reading, printing results, loading the 20 stations. |

---

## 4. Data structures implemented in C

| Data structure | File | Used for |
|---|---|---|
| **Graph** (adjacency list) | `metro_graph.c` | Stations = vertices, connections = edges with a travel time |
| **Singly linked list** | `linked_list.c` | The adjacency list of each station (one node per connection) |
| **Queue** (circular array) | `queue.c` | The BFS "to visit" list in `sp_fewest_stops` |
| **Binary min-heap** (priority queue) | `shortest_path.c` (private) | Dijkstra picks the unvisited station with the smallest distance |
| **Dynamic arrays** | `metro_graph.c`, `queue.c`, `shortest_path.c` | `realloc`-grown arrays; `dist[]`, `parent[]`, `visited[]` |

Memory functions: `malloc` (list nodes, arrays), `calloc` (graph struct,
`visited[]`), `realloc` (growing station array, queue and heap), `free` (every
destructor / cleanup path).

### How the graph and adjacency list represent the metro

Each station has an id (0–19) and its own linked list of `(destination, time)`
nodes. A bidirectional connection is stored **twice** (once in each station's list).

```
stations[ ]                      adjacency lists
 [0] Prem Nagar   ──► (1 ISBT, 5) ──► (19 Premnagar Chowk, 2) ──► NULL
 [1] ISBT         ──► (0 Prem Nagar, 5) ──► (2 Clock Tower, 4) ──► (16 Dehradun Railway Stn, 3) ──► NULL
 [2] Clock Tower  ──► (1 ISBT, 4) ──► (3 Rajpur Road, 3) ──► (10 Jogiwala, 6) ──► NULL
  ...
```

Why an adjacency list and not a matrix? A metro is *sparse* (20 stations, 21
connections, ≈ 2 neighbours each). A 20×20 matrix would be mostly empty; the list
uses space proportional to what exists: **O(V + E)**.

---

## 5. OOP concepts implemented in C++

| Concept | Where | How |
|---|---|---|
| **Classes & objects** | `MetroStation`, `MetroNetwork`, `RoutePlanner`, `RouteResult`, `MetroRouteApp` | Each class has one clear job |
| **Encapsulation** | all classes | Data members are `private`; the C pointer in `MetroNetwork` is never exposed for modification; `MetroStation::addConnection` rejects bad values; `RouteResult` is read-only |
| **Constructors / destructors** | `MetroNetwork` | Constructor calls `mg_create()` (throws `std::bad_alloc` on failure); destructor calls `mg_destroy()` — this is **RAII** |
| **Copy / move control** | `MetroNetwork` | Copy is `= delete` (two owners would free the same graph twice). Move transfers ownership and sets the old pointer to `NULL`. Prevents double-free and dangling pointers |
| **Abstraction** | `MetroNetwork`, `RoutePlanner` | Other code asks *"plan a route from A to B"* and never sees arrays, pointers or error codes |
| **Inheritance** | `FastestRouteStrategy`, `FewestStopsStrategy` → `RouteStrategy` | Two different ways to plan a route share one interface |
| **Polymorphism** | `RoutePlanner::planRoute()` | Calls `strategy_->findRoute(...)` through a base-class pointer; at run time that runs Dijkstra *or* BFS (`virtual` + `override`). Menu option 3 vs 4 swaps the object. |
| **Smart pointers** | `RoutePlanner` | `std::unique_ptr<RouteStrategy>` frees the strategy automatically |
| **Exceptions** | `MetroNetwork` | Bad input while *building* the network throws `std::invalid_argument` |

---

## 6. Algorithms

### Dijkstra's algorithm — least travel time (`sp_dijkstra`)

1. `dist[]` = ∞ for every station, `dist[source] = 0`; `parent[]` = −1; `visited[]` = false.
2. Put `(0, source)` in the **min-heap**.
3. Repeat: take the smallest `(distance, station u)` from the heap.
   If `u` is already visited, skip it (an outdated entry). Otherwise mark it visited.
   If `u` is the destination, stop — its distance is final.
4. For every neighbour `v` of `u` (walk `u`'s linked list): if `dist[u] + time < dist[v]`,
   update `dist[v]`, set `parent[v] = u`, push `(dist[v], v)`.
5. If `dist[destination]` is still ∞ → **no route** (`SP_ERR_NO_PATH`).
6. Otherwise follow `parent[]` from the destination back to the source, store the
   ids in forward order, and return them together with `dist[destination]`.

Dijkstra needs non-negative weights; `mg_add_connection` rejects any travel time ≤ 0, so this always holds.

### Breadth-First Search — fewest stops (`sp_fewest_stops`)

Uses the **queue**: enqueue the source; repeatedly dequeue a station and enqueue
all its unvisited neighbours. Because BFS explores in "rings" (1 stop away, 2 stops
away, …), the first time it reaches the destination is with the fewest stops.
If two routes have the same number of stops, the **quicker one is kept**
(a station reached again from the same BFS level with a smaller time updates its parent).

> **Honest note:** on the shipped 20-station network the fastest route always
> already has the fewest stops, so options 3 and 4 give the same stops and time for
> all 380 station pairs (only equal-cost alternatives can differ). The two options
> diverge on networks with a slow direct link — see the `A-B-C` test in
> `test_c_modules.c` (direct link: 1 stop / 10 min vs. via B: 2 stops / 2 min).

### Complexity

*V* = stations, *E* = connections (each stored twice in the lists).

| Operation | Time | Extra space |
|---|---|---|
| `ll_append` (tail pointer) | O(1) | O(1) |
| `ll_contains`, `ll_remove` | O(degree) | O(1) |
| `queue_enqueue` / `queue_dequeue` | O(1) (enqueue amortised, because of occasional doubling) | — |
| `mg_add_station` | O(V) (duplicate-name check) | O(1) amortised |
| `mg_find_station` (by name) | O(V) linear search | O(1) |
| `mg_add_connection` | O(degree) | O(1) |
| **Dijkstra** | **O((V + E) log V)** | O(V + E) |
| **BFS** | **O(V + E)** | O(V) |
| Path reconstruction | O(V) | O(V) |
| Whole graph | — | O(V + E) |

The original program used a hash map (`unordered_map`) for name→id lookup (O(1)).
The C version uses a linear search because C has no built-in hash map; for 20
stations this is instant, and it keeps the code simple to explain.

---

## 7. Compile and run

**Windows (MinGW), from the project folder:**

```bat
build.bat
metroroute.exe
```

Other modes: `build.bat run`, `build.bat test`, `build.bat clean`.
Full details and troubleshooting: [COMPILATION_GUIDE.md](COMPILATION_GUIDE.md).

---

## 8. Sample input / output

(What you type is shown after each prompt.)

```
========================================
  Initializing Metro Network...
========================================
Metro network loaded successfully!
Total Stations: 20
Total Connections: 21

====================================
       METROROUTE
  SMART METRO NAVIGATION SYSTEM
====================================
1. View All Stations
2. View Metro Network
3. Find Shortest Route (least time)
4. Find Route with Fewest Stops
5. Exit
====================================
Enter your choice: 3

Enter source station: Prem Nagar
Enter destination station: Ballupur

========== SHORTEST ROUTE ==========
  Prem Nagar
      |
      v
  ISBT
      |
      v
  Clock Tower
      |
      v
  Rajpur Road
      |
      v
  EC Road
      |
      v
  Race Course
      |
      v
  Ballupur

====================================
Total Stops: 6
Estimated Travel Time: 27 minutes
Algorithm Used: Dijkstra's Algorithm
====================================
```

Error handling (real output):

```
Enter source station: Foo
Enter destination station: ISBT
Error: Source station 'Foo' not found!

Enter source station: ISBT
Enter destination station: ISBT
You are already at the destination!

Enter your choice: abc
Invalid choice! Please enter 1-5.
```

If two stations are not connected the program prints
`No route found between <A> and <B>!`. The shipped network is fully connected, so this
case is verified by the automated tests (a station with no connections).

---

## 9. Testing

```bat
build.bat test
```

| Test file | Language | What it checks |
|---|---|---|
| `test_c_modules.c` | C | list, queue (wrap-around, growth, empty), graph validation and growth, **all 400 station pairs of the real network checked against an independent Floyd–Warshall implementation** (time for Dijkstra; stops-then-time for BFS), invalid ids, NULL pointers, unreachable stations, 2000-station stress test |
| `test_cpp_integration.cpp` | C++ | each class, exceptions, move semantics (no double free), every `RouteStatus`, polymorphic strategies, 200 create/destroy cycles |

Results (10,340 + 265 checks, 0 failed), AddressSanitizer / LeakSanitizer / UBSan
runs, and a comparison with the original program over all 380 station pairs
(380/380 identical) are in `backend/tests/TEST_RESULTS.txt`.

**What was and was not verified:** everything was built and run on Linux with
GCC 13. `build.bat` has **not** been executed on Windows; the exact compiler and
linker commands inside it were extracted and executed successfully, but the batch
control flow (error labels, `test`/`run`/`clean` modes) is untested on Windows.

---

## 10. What changed from the original project

| Area | Original | Now |
|---|---|---|
| Graph, adjacency list, Dijkstra | C++ (`vector`, `priority_queue`, `unordered_map`) inside class `MetroGraph` | **C**: `metro_graph.c`, `linked_list.c`, `shortest_path.c` |
| Queue | not present | **C**: `queue.c`, used by BFS |
| Class `MetroGraph` | stored data **and** ran Dijkstra **and** printed | Split into `MetroNetwork` (owns the C graph), `RoutePlanner` + strategies (algorithms), `MetroRouteApp` (printing) |
| Class `MetroStation` | kept | kept (read-only value object built from C data) |
| Inheritance / polymorphism | none | `RouteStrategy` → `FastestRouteStrategy`, `FewestStopsStrategy` |
| Menu | 1–3 + `4 Exit` | 1–3 unchanged, **new 4: Fewest Stops**, `5 Exit` |
| Invalid menu input | typing letters caused an **infinite loop** | any bad input prints a message and re-prompts; end of input exits cleanly |
| Station names | exact match | case-insensitive, surrounding spaces ignored |
| Route arrows | `↓` (garbled in many Windows consoles) | ASCII `|` and `v` |
| "Total Stations" | hard-coded `20` | read from the network, plus "Total Connections: 21" |
| Documentation | README said 24 connections | corrected to **21** (the number in the original code) |
| Build | one `g++` command | `build.bat` / `build.sh`: gcc for `.c`, g++ for `.cpp`, one link step |
| Tests | none | two test programs |

**Unchanged:** the 20 stations, 21 connections and all travel times, the
"View stations" and "View network" output (byte-identical to the original), and
every route/time/stop count (verified for all 380 pairs).

---

## 11. Limitations and future work

- Console only; simulated (fictional) Dehradun network, not real data.
- No interchange time or fare calculation.
- Stations are added in code (`loadDefaultNetwork`); loading from a file would be a natural extension.
- Name lookup is O(V); a hash table in C would make it O(1).
- Possible extension: a third strategy (e.g. "fewest line changes") — just add another class deriving from `RouteStrategy`.
