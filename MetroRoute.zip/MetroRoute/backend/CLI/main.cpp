// main.cpp - entry point of MetroRoute.
#include <exception>
#include <iostream>
#include "../include/metro_route_app.hpp"

int main() {
    try {
        MetroRouteApp app;
        app.run();
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
