#include "../include/metro_station.h"

// Default constructor: an "empty" station that is not part of any network
MetroStation::MetroStation() : id_(-1), name_("") {}

MetroStation::MetroStation(int stationId, const std::string& stationName)
    : id_(stationId), name_(stationName) {}

int MetroStation::getId() const {
    return id_;
}

const std::string& MetroStation::getName() const {
    return name_;
}

const std::vector<Connection>& MetroStation::getConnections() const {
    return connections_;
}

int MetroStation::getConnectionCount() const {
    return static_cast<int>(connections_.size());
}

void MetroStation::addConnection(int destinationId, int travelTime) {
    // Encapsulation: the object protects its own state from bad data.
    if (destinationId < 0 || travelTime <= 0) return;
    connections_.push_back(Connection(destinationId, travelTime));
}
