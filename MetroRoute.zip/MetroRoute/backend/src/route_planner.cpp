#include "../include/route_planner.hpp"
#include "../c_modules/shortest_path.h"
#include <utility>

// ---------------------------------------------------------------------------
// RouteResult
// ---------------------------------------------------------------------------
RouteResult::RouteResult()
    : status_(RouteStatus::Error), strategyName_(), stationIds_(), totalTime_(0) {}

RouteResult::RouteResult(RouteStatus status, const std::string& strategyName,
                         const std::vector<int>& stationIds, int totalTime)
    : status_(status), strategyName_(strategyName),
      stationIds_(stationIds), totalTime_(totalTime) {}

RouteStatus RouteResult::getStatus() const { return status_; }
bool RouteResult::isFound() const { return status_ == RouteStatus::Found; }
const std::string& RouteResult::getStrategyName() const { return strategyName_; }
const std::vector<int>& RouteResult::getStationIds() const { return stationIds_; }
int RouteResult::getTotalTime() const { return totalTime_; }

int RouteResult::getStopCount() const {
    if (stationIds_.empty()) return 0;
    return static_cast<int>(stationIds_.size()) - 1;
}

// ---------------------------------------------------------------------------
// C <-> C++ boundary helper (private to this file)
// ---------------------------------------------------------------------------
namespace {

// RAII guard: owns a C PathResult and ALWAYS calls sp_free_result() when it
// goes out of scope - even if an exception (e.g. std::bad_alloc while copying
// into a std::vector) is thrown. This is how C memory ownership is made safe
// on the C++ side.
class PathGuard {
public:
    PathResult path;

    PathGuard() { path.stations = NULL; path.length = 0; path.total_time = 0; }
    ~PathGuard() { sp_free_result(&path); }

private:
    PathGuard(const PathGuard&);              // not copyable (single owner)
    PathGuard& operator=(const PathGuard&);
};

// Translate the C status code + PathResult into a C++ RouteResult.
RouteResult toRouteResult(int cStatus, const PathResult& path,
                          const std::string& strategyName) {
    switch (cStatus) {
        case SP_OK: {
            std::vector<int> ids(path.stations, path.stations + path.length);
            return RouteResult(RouteStatus::Found, strategyName, ids, path.total_time);
        }
        case SP_ERR_NO_PATH:
            return RouteResult(RouteStatus::NoRoute, strategyName);
        default:
            return RouteResult(RouteStatus::Error, strategyName);
    }
}

}  // namespace

// ---------------------------------------------------------------------------
// Strategies (derived classes overriding the virtual functions)
// ---------------------------------------------------------------------------
std::string FastestRouteStrategy::getName() const {
    return "Dijkstra's Algorithm";
}

RouteResult FastestRouteStrategy::findRoute(const MetroNetwork& network,
                                            int sourceId, int destinationId) const {
    PathGuard guard;
    int status = sp_dijkstra(network.cGraph(), sourceId, destinationId, &guard.path);
    return toRouteResult(status, guard.path, getName());
}

std::string FewestStopsStrategy::getName() const {
    return "Breadth-First Search (fewest stops)";
}

RouteResult FewestStopsStrategy::findRoute(const MetroNetwork& network,
                                           int sourceId, int destinationId) const {
    PathGuard guard;
    int status = sp_fewest_stops(network.cGraph(), sourceId, destinationId, &guard.path);
    return toRouteResult(status, guard.path, getName());
}

// ---------------------------------------------------------------------------
// RoutePlanner
// ---------------------------------------------------------------------------
RoutePlanner::RoutePlanner(const MetroNetwork& network)
    : network_(network), strategy_(new FastestRouteStrategy()) {}

void RoutePlanner::setStrategy(std::unique_ptr<RouteStrategy> strategy) {
    if (strategy) strategy_ = std::move(strategy);
}

std::string RoutePlanner::getStrategyName() const {
    return strategy_->getName();
}

RouteResult RoutePlanner::planRoute(const std::string& source,
                                    const std::string& destination) const {
    const std::string name = strategy_->getName();

    int sourceId = network_.getStationId(source);
    if (sourceId < 0) return RouteResult(RouteStatus::SourceNotFound, name);

    int destinationId = network_.getStationId(destination);
    if (destinationId < 0) return RouteResult(RouteStatus::DestinationNotFound, name);

    if (sourceId == destinationId) {
        return RouteResult(RouteStatus::SameStation, name,
                           std::vector<int>(1, sourceId), 0);
    }

    // Polymorphic call: runs Dijkstra or BFS depending on the strategy object.
    return strategy_->findRoute(network_, sourceId, destinationId);
}
