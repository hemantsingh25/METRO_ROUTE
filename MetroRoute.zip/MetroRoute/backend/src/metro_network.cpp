#include "../include/metro_network.hpp"
#include <new>
#include <stdexcept>
#include <utility>

namespace {

// Remove leading/trailing blanks so " ISBT " matches "ISBT".
std::string trim(const std::string& text) {
    const char* blanks = " \t\r\n";
    std::string::size_type first = text.find_first_not_of(blanks);
    if (first == std::string::npos) return "";
    std::string::size_type last = text.find_last_not_of(blanks);
    return text.substr(first, last - first + 1);
}

}  // namespace

MetroNetwork::MetroNetwork() : graph_(mg_create()) {
    if (graph_ == NULL) throw std::bad_alloc();
}

MetroNetwork::~MetroNetwork() {
    mg_destroy(graph_);   // NULL-safe, so a moved-from object is fine too
}

MetroNetwork::MetroNetwork(MetroNetwork&& other) noexcept : graph_(other.graph_) {
    other.graph_ = NULL;  // the old object no longer owns the graph
}

MetroNetwork& MetroNetwork::operator=(MetroNetwork&& other) noexcept {
    if (this != &other) {
        mg_destroy(graph_);       // release what we own now
        graph_ = other.graph_;    // take over the other graph
        other.graph_ = NULL;
    }
    return *this;
}

int MetroNetwork::addStation(const std::string& name) {
    std::string clean = trim(name);
    int result = mg_add_station(graph_, clean.c_str());

    if (result >= 0) return result;
    if (result == MG_ERR_DUPLICATE) {
        throw std::invalid_argument("Station '" + clean + "' already exists");
    }
    if (result == MG_ERR_INVALID_ARG) {
        throw std::invalid_argument("Invalid station name: '" + clean + "'");
    }
    throw std::runtime_error(std::string("Cannot add station: ") + mg_status_message(result));
}

void MetroNetwork::addConnection(const std::string& station1,
                                 const std::string& station2, int travelTime) {
    int id1 = getStationId(station1);
    int id2 = getStationId(station2);
    if (id1 < 0 || id2 < 0) {
        throw std::invalid_argument("One or both stations don't exist: '" +
                                    station1 + "', '" + station2 + "'");
    }

    int result = mg_add_connection(graph_, id1, id2, travelTime);
    if (result == MG_OK) return;
    if (result == MG_ERR_DUPLICATE || result == MG_ERR_INVALID_ARG) {
        throw std::invalid_argument(std::string("Cannot connect '") + station1 + "' and '" +
                                    station2 + "': " + mg_status_message(result));
    }
    throw std::runtime_error(std::string("Cannot add connection: ") + mg_status_message(result));
}

int MetroNetwork::getStationCount() const {
    return mg_station_count(graph_);
}

int MetroNetwork::getConnectionCount() const {
    return mg_connection_count(graph_);
}

bool MetroNetwork::stationExists(const std::string& name) const {
    return getStationId(name) != -1;
}

int MetroNetwork::getStationId(const std::string& name) const {
    return mg_find_station(graph_, trim(name).c_str());
}

std::string MetroNetwork::getStationName(int stationId) const {
    const char* name = mg_station_name(graph_, stationId);
    return (name == NULL) ? std::string() : std::string(name);
}

MetroStation MetroNetwork::getStation(int stationId) const {
    const char* name = mg_station_name(graph_, stationId);
    if (name == NULL) throw std::out_of_range("Invalid station id");

    MetroStation station(stationId, name);

    // Walk the C linked list (adjacency list) and copy it into the C++ object.
    const LinkedList* list = mg_neighbors(graph_, stationId);
    for (const ListNode* node = list->head; node != NULL; node = node->next) {
        station.addConnection(node->destination, node->travel_time);
    }
    return station;
}

std::vector<MetroStation> MetroNetwork::getAllStations() const {
    std::vector<MetroStation> all;
    int count = getStationCount();
    all.reserve(static_cast<size_t>(count));
    for (int id = 0; id < count; id++) {
        all.push_back(getStation(id));
    }
    return all;
}

const MetroGraph* MetroNetwork::cGraph() const {
    return graph_;
}
