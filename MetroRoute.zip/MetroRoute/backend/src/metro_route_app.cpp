#include "../include/metro_route_app.hpp"
#include <iostream>
#include <memory>

using namespace std;

MetroRouteApp::MetroRouteApp() : network_(), planner_(network_) {
    loadDefaultNetwork();
}

// ---------------------------------------------------------------------------
// The original 20-station Dehradun metro network (same stations, connections
// and travel times as the original C++-only version).
// ---------------------------------------------------------------------------
void MetroRouteApp::loadDefaultNetwork() {
    // Add stations
    network_.addStation("Prem Nagar");
    network_.addStation("ISBT");
    network_.addStation("Clock Tower");
    network_.addStation("Rajpur Road");
    network_.addStation("EC Road");
    network_.addStation("Race Course");
    network_.addStation("Ballupur");
    network_.addStation("Patel Nagar");
    network_.addStation("Clement Town");
    network_.addStation("Sahastradhara");
    network_.addStation("Jogiwala");
    network_.addStation("Mussoorie Diversion");
    network_.addStation("Selaqui");
    network_.addStation("Herbertpur");
    network_.addStation("Vikasnagar");
    network_.addStation("Rajaji National Park");
    network_.addStation("Dehradun Railway Station");
    network_.addStation("Rispana");
    network_.addStation("Hathibarkala");
    network_.addStation("Premnagar Chowk");

    // Add connections (bidirectional, travel time in minutes)
    // Orange Line (Main Line)
    network_.addConnection("Prem Nagar", "ISBT", 5);
    network_.addConnection("ISBT", "Clock Tower", 4);
    network_.addConnection("Clock Tower", "Rajpur Road", 3);
    network_.addConnection("Rajpur Road", "EC Road", 6);
    network_.addConnection("EC Road", "Race Course", 4);
    network_.addConnection("Race Course", "Ballupur", 5);
    network_.addConnection("Ballupur", "Mussoorie Diversion", 7);

    // Blue Line (Southern Route)
    network_.addConnection("Rajpur Road", "Patel Nagar", 7);
    network_.addConnection("Patel Nagar", "Clement Town", 5);
    network_.addConnection("Clement Town", "Sahastradhara", 8);
    network_.addConnection("Sahastradhara", "Rajaji National Park", 10);

    // Green Line (Western Route)
    network_.addConnection("Clock Tower", "Jogiwala", 6);
    network_.addConnection("Jogiwala", "Rispana", 5);
    network_.addConnection("Rispana", "Hathibarkala", 4);

    // Yellow Line (Extended Route)
    network_.addConnection("ISBT", "Dehradun Railway Station", 3);
    network_.addConnection("Dehradun Railway Station", "Premnagar Chowk", 4);
    network_.addConnection("Premnagar Chowk", "Selaqui", 9);
    network_.addConnection("Selaqui", "Herbertpur", 12);
    network_.addConnection("Herbertpur", "Vikasnagar", 8);

    // Connector lines
    network_.addConnection("Prem Nagar", "Premnagar Chowk", 2);
    network_.addConnection("EC Road", "Clement Town", 9);
}

// ---------------------------------------------------------------------------
// Input helpers
// ---------------------------------------------------------------------------
bool MetroRouteApp::readLine(string& line) {
    return static_cast<bool>(getline(cin, line));
}

bool MetroRouteApp::readChoice(int& choice) {
    string line;
    choice = -1;
    if (!readLine(line)) return false;   // end of input

    // Accept only 1-9 digits (optionally surrounded by blanks).
    string::size_type first = line.find_first_not_of(" \t\r");
    if (first == string::npos) return true;
    string::size_type last = line.find_last_not_of(" \t\r");
    string digits = line.substr(first, last - first + 1);

    if (digits.size() > 9) return true;
    for (string::size_type i = 0; i < digits.size(); i++) {
        if (digits[i] < '0' || digits[i] > '9') return true;
    }
    choice = stoi(digits);
    return true;
}

// ---------------------------------------------------------------------------
// Screens
// ---------------------------------------------------------------------------
void MetroRouteApp::showMenu() const {
    cout << "\n====================================\n";
    cout << "       METROROUTE\n";
    cout << "  SMART METRO NAVIGATION SYSTEM\n";
    cout << "====================================\n";
    cout << "1. View All Stations\n";
    cout << "2. View Metro Network\n";
    cout << "3. Find Shortest Route (least time)\n";
    cout << "4. Find Route with Fewest Stops\n";
    cout << "5. Exit\n";
    cout << "====================================\n";
    cout << "Enter your choice: ";
}

void MetroRouteApp::viewAllStations() const {
    cout << "\n========== ALL METRO STATIONS ==========\n";
    int count = network_.getStationCount();
    for (int i = 0; i < count; i++) {
        cout << (i + 1) << ". " << network_.getStationName(i) << endl;
    }
    cout << "========================================\n";
}

void MetroRouteApp::viewNetwork() const {
    cout << "\n========== METRO NETWORK ==========\n";
    vector<MetroStation> stations = network_.getAllStations();
    for (size_t i = 0; i < stations.size(); i++) {
        cout << "\n" << stations[i].getName() << " connects to:\n";
        const vector<Connection>& connections = stations[i].getConnections();

        if (connections.empty()) {
            cout << "  (No connections)\n";
        } else {
            for (size_t j = 0; j < connections.size(); j++) {
                cout << "  -> " << network_.getStationName(connections[j].destinationId)
                     << " (" << connections[j].travelTime << " min)\n";
            }
        }
    }
    cout << "===================================\n";
}

void MetroRouteApp::findRoute(bool fewestStops) {
    string source, destination;

    cout << "\nEnter source station: ";
    if (!readLine(source)) return;
    cout << "Enter destination station: ";
    if (!readLine(destination)) return;

    // Choose the strategy object at run time (polymorphism).
    if (fewestStops) {
        planner_.setStrategy(unique_ptr<RouteStrategy>(new FewestStopsStrategy()));
    } else {
        planner_.setStrategy(unique_ptr<RouteStrategy>(new FastestRouteStrategy()));
    }

    printResult(planner_.planRoute(source, destination), source, destination);
}

void MetroRouteApp::printResult(const RouteResult& result, const string& source,
                                const string& destination) const {
    switch (result.getStatus()) {
        case RouteStatus::SourceNotFound:
            cout << "\nError: Source station '" << source << "' not found!\n";
            return;
        case RouteStatus::DestinationNotFound:
            cout << "\nError: Destination station '" << destination << "' not found!\n";
            return;
        case RouteStatus::SameStation:
            cout << "\nYou are already at the destination!\n";
            return;
        case RouteStatus::NoRoute:
            cout << "\nNo route found between " << source << " and " << destination << "!\n";
            return;
        case RouteStatus::Error:
            cout << "\nError: the route could not be calculated.\n";
            return;
        case RouteStatus::Found:
            break;
    }

    const vector<int>& path = result.getStationIds();

    cout << "\n========== SHORTEST ROUTE ==========\n";
    for (size_t i = 0; i < path.size(); i++) {
        cout << "  " << network_.getStationName(path[i]) << endl;
        if (i + 1 < path.size()) {
            cout << "      |" << endl;
            cout << "      v" << endl;
        }
    }

    cout << "\n====================================\n";
    cout << "Total Stops: " << result.getStopCount() << endl;
    cout << "Estimated Travel Time: " << result.getTotalTime() << " minutes\n";
    cout << "Algorithm Used: " << result.getStrategyName() << endl;
    cout << "====================================\n";
}

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
void MetroRouteApp::run() {
    cout << "\n========================================\n";
    cout << "  Initializing Metro Network...\n";
    cout << "========================================\n";
    cout << "Metro network loaded successfully!\n";
    cout << "Total Stations: " << network_.getStationCount() << endl;
    cout << "Total Connections: " << network_.getConnectionCount() << endl;

    int choice = 0;
    do {
        showMenu();
        if (!readChoice(choice)) {          // input ended (Ctrl+Z / Ctrl+D / pipe)
            cout << "\n";
            choice = 5;
        }

        switch (choice) {
            case 1: viewAllStations(); break;
            case 2: viewNetwork(); break;
            case 3: findRoute(false); break;
            case 4: findRoute(true); break;
            case 5: break;
            default:
                cout << "\nInvalid choice! Please enter 1-5.\n";
        }
    } while (choice != 5);

    cout << "\n========================================\n";
    cout << "  Thank you for using MetroRoute!\n";
    cout << "========================================\n";
}
