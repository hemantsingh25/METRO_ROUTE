/* shortest_path.c - Dijkstra (min-heap) and BFS (queue) in pure C. */
#include <stdlib.h>
#include <limits.h>
#include "shortest_path.h"
#include "queue.h"

#define INFINITE_TIME INT_MAX   /* "not reached yet" marker for distances */

/* ======================================================================== *
 *  Binary min-heap (priority queue) - private to this file.
 *  Stores (distance, station) pairs; the smallest distance is always at the
 *  root. Uses "lazy deletion": outdated entries are simply skipped when they
 *  are popped, so no decrease-key operation is needed.
 * ======================================================================== */
typedef struct HeapItem {
    int distance;
    int station;
} HeapItem;

typedef struct MinHeap {
    HeapItem *items;
    int size;
    int capacity;
} MinHeap;

static int heap_init(MinHeap *h, int capacity)
{
    if (capacity < 1) capacity = 1;
    h->items = (HeapItem *)malloc((size_t)capacity * sizeof(HeapItem));
    h->size = 0;
    h->capacity = (h->items == NULL) ? 0 : capacity;
    return (h->items == NULL) ? -1 : 0;
}

static void heap_destroy(MinHeap *h)
{
    free(h->items);
    h->items = NULL;
    h->size = 0;
    h->capacity = 0;
}

static void heap_swap(HeapItem *a, HeapItem *b)
{
    HeapItem tmp = *a;
    *a = *b;
    *b = tmp;
}

static int heap_push(MinHeap *h, int distance, int station)
{
    int i;

    if (h->size == h->capacity) {                    /* grow when full */
        int new_capacity;
        HeapItem *bigger;
        if (h->capacity > INT_MAX / 2) return -1;
        new_capacity = h->capacity * 2;
        bigger = (HeapItem *)realloc(h->items, (size_t)new_capacity * sizeof(HeapItem));
        if (bigger == NULL) return -1;
        h->items = bigger;
        h->capacity = new_capacity;
    }

    i = h->size++;
    h->items[i].distance = distance;
    h->items[i].station = station;

    while (i > 0) {                                  /* sift up */
        int parent = (i - 1) / 2;
        if (h->items[parent].distance <= h->items[i].distance) break;
        heap_swap(&h->items[parent], &h->items[i]);
        i = parent;
    }
    return 0;
}

/* Remove the smallest item. The heap must not be empty. */
static HeapItem heap_pop(MinHeap *h)
{
    HeapItem top = h->items[0];
    int i = 0;

    h->items[0] = h->items[--h->size];
    for (;;) {                                       /* sift down */
        int left = 2 * i + 1;
        int right = left + 1;
        int smallest = i;
        if (left < h->size && h->items[left].distance < h->items[smallest].distance) smallest = left;
        if (right < h->size && h->items[right].distance < h->items[smallest].distance) smallest = right;
        if (smallest == i) break;
        heap_swap(&h->items[i], &h->items[smallest]);
        i = smallest;
    }
    return top;
}

/* ======================================================================== *
 *  Shared helpers
 * ======================================================================== */

static void reset_result(PathResult *r)
{
    r->stations = NULL;
    r->length = 0;
    r->total_time = 0;
}

/* Follow parent[] from the destination back to the source, then store the ids
 * in forward order (source ... destination). Returns SP_OK or SP_ERR_NOMEM. */
static int build_path(const int *parent, int destination, int total_time,
                      PathResult *result)
{
    int length = 0;
    int node;
    int i;
    int *path;

    for (node = destination; node != -1; node = parent[node]) length++;

    path = (int *)malloc((size_t)length * sizeof(int));
    if (path == NULL) return SP_ERR_NOMEM;

    i = length - 1;                                  /* fill from the back */
    for (node = destination; node != -1; node = parent[node]) path[i--] = node;

    result->stations = path;
    result->length = length;
    result->total_time = total_time;
    return SP_OK;
}

/* Checks pointers and ids shared by both algorithms. */
static int check_arguments(const MetroGraph *graph, int source, int destination,
                           PathResult *result)
{
    if (result == NULL) return SP_ERR_NULL;
    reset_result(result);
    if (graph == NULL) return SP_ERR_NULL;
    if (source < 0 || source >= mg_station_count(graph) ||
        destination < 0 || destination >= mg_station_count(graph)) {
        return SP_ERR_INVALID_STATION;
    }
    return SP_OK;
}

/* ======================================================================== *
 *  Dijkstra's algorithm
 * ======================================================================== */
int sp_dijkstra(const MetroGraph *graph, int source, int destination,
                PathResult *result)
{
    int n;
    int *dist = NULL;
    int *parent = NULL;
    char *visited = NULL;
    MinHeap heap;
    int status;

    status = check_arguments(graph, source, destination, result);
    if (status != SP_OK) return status;

    n = mg_station_count(graph);
    dist = (int *)malloc((size_t)n * sizeof(int));
    parent = (int *)malloc((size_t)n * sizeof(int));
    visited = (char *)calloc((size_t)n, sizeof(char));       /* all 0 = false */
    heap.items = NULL;

    if (dist == NULL || parent == NULL || visited == NULL ||
        heap_init(&heap, n) != 0) {
        status = SP_ERR_NOMEM;
        goto cleanup;
    }

    {
        int i;
        for (i = 0; i < n; i++) {
            dist[i] = INFINITE_TIME;
            parent[i] = -1;
        }
    }

    dist[source] = 0;
    if (heap_push(&heap, 0, source) != 0) {
        status = SP_ERR_NOMEM;
        goto cleanup;
    }

    while (heap.size > 0) {
        HeapItem top = heap_pop(&heap);
        int u = top.station;
        const ListNode *edge;

        if (visited[u]) continue;        /* stale heap entry, skip it */
        visited[u] = 1;

        if (u == destination) break;     /* shortest path to target is final */

        /* Relax every edge u -> v stored in u's adjacency list. */
        for (edge = mg_neighbors(graph, u)->head; edge != NULL; edge = edge->next) {
            int v = edge->destination;
            int w = edge->travel_time;

            if (visited[v]) continue;
            if (w > INFINITE_TIME - dist[u]) continue;       /* overflow guard */

            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                parent[v] = u;
                if (heap_push(&heap, dist[v], v) != 0) {
                    status = SP_ERR_NOMEM;
                    goto cleanup;
                }
            }
        }
    }

    if (dist[destination] == INFINITE_TIME) {
        status = SP_ERR_NO_PATH;
    } else {
        status = build_path(parent, destination, dist[destination], result);
    }

cleanup:
    heap_destroy(&heap);
    free(visited);
    free(parent);
    free(dist);
    return status;
}

/* ======================================================================== *
 *  Breadth-First Search (fewest stops)
 * ======================================================================== */
int sp_fewest_stops(const MetroGraph *graph, int source, int destination,
                    PathResult *result)
{
    int n;
    int *parent = NULL;
    int *hops = NULL;          /* number of connections from the source     */
    int *time_to = NULL;       /* travel time along the route found so far  */
    char *visited = NULL;
    Queue queue;
    int status;
    int queue_ready = 0;

    status = check_arguments(graph, source, destination, result);
    if (status != SP_OK) return status;

    n = mg_station_count(graph);
    parent = (int *)malloc((size_t)n * sizeof(int));
    hops = (int *)calloc((size_t)n, sizeof(int));
    time_to = (int *)calloc((size_t)n, sizeof(int));
    visited = (char *)calloc((size_t)n, sizeof(char));

    if (parent == NULL || hops == NULL || time_to == NULL || visited == NULL ||
        queue_init(&queue, n) != 0) {
        status = SP_ERR_NOMEM;
        goto cleanup;
    }
    queue_ready = 1;

    {
        int i;
        for (i = 0; i < n; i++) parent[i] = -1;
    }

    visited[source] = 1;
    if (queue_enqueue(&queue, source) != 0) {
        status = SP_ERR_NOMEM;
        goto cleanup;
    }

    while (!queue_is_empty(&queue)) {
        int u;
        const ListNode *edge;

        queue_dequeue(&queue, &u);
        if (u == destination) break;     /* first arrival = fewest stops */

        for (edge = mg_neighbors(graph, u)->head; edge != NULL; edge = edge->next) {
            int v = edge->destination;
            int new_time = time_to[u] + edge->travel_time;

            if (!visited[v]) {                      /* first time we reach v */
                visited[v] = 1;
                parent[v] = u;
                hops[v] = hops[u] + 1;
                time_to[v] = new_time;
                if (queue_enqueue(&queue, v) != 0) {
                    status = SP_ERR_NOMEM;
                    goto cleanup;
                }
            } else if (hops[v] == hops[u] + 1 && new_time < time_to[v]) {
                /* Tie-break: v was already reached with the same number of
                 * stops, but this way is quicker. BFS finishes a whole level
                 * before the next one starts, so v has not been expanded yet
                 * and its time can still safely be improved. */
                parent[v] = u;
                time_to[v] = new_time;
            }
        }
    }

    if (!visited[destination]) {
        status = SP_ERR_NO_PATH;
    } else {
        status = build_path(parent, destination, time_to[destination], result);
    }

cleanup:
    if (queue_ready) queue_destroy(&queue);
    free(visited);
    free(time_to);
    free(hops);
    free(parent);
    return status;
}

void sp_free_result(PathResult *result)
{
    if (result == NULL) return;
    free(result->stations);
    reset_result(result);
}

const char *sp_status_message(int status)
{
    switch (status) {
        case SP_OK:                  return "success";
        case SP_ERR_NULL:            return "null pointer";
        case SP_ERR_INVALID_STATION: return "invalid station";
        case SP_ERR_NO_PATH:         return "no route exists";
        case SP_ERR_NOMEM:           return "out of memory";
        default:                     return "unknown error";
    }
}
