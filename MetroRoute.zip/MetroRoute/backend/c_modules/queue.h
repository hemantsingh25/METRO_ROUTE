/*
 * queue.h - FIFO queue of integers (pure C).
 *
 * Implemented as a CIRCULAR ARRAY that doubles its size with realloc() when it
 * becomes full, so enqueue/dequeue are both O(1) (amortised).
 * Used by the Breadth-First Search that finds the route with the fewest stops.
 */
#ifndef QUEUE_H
#define QUEUE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Queue {
    int *data;        /* heap-allocated circular buffer */
    int capacity;     /* number of slots in 'data'      */
    int front;        /* index of the oldest element    */
    int count;        /* number of stored elements      */
} Queue;

/* Prepare a queue. 'initial_capacity' <= 0 selects a default (8).
 * Returns 0 on success, -1 on NULL pointer or allocation failure. */
int queue_init(Queue *q, int initial_capacity);

/* Add 'value' at the back. Grows the buffer when full.
 * Returns 0 on success, -1 on failure (queue is left unchanged). */
int queue_enqueue(Queue *q, int value);

/* Remove the front element and store it in *out.
 * Returns 0 on success, -1 if the queue is empty or a pointer is NULL. */
int queue_dequeue(Queue *q, int *out);

/* Returns 1 if the queue holds no elements (or q is NULL), otherwise 0. */
int queue_is_empty(const Queue *q);

/* Number of elements currently stored. */
int queue_size(const Queue *q);

/* Release the buffer. Safe to call twice. */
void queue_destroy(Queue *q);

#ifdef __cplusplus
}
#endif

#endif /* QUEUE_H */
