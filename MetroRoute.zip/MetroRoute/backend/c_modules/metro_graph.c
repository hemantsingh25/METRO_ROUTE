/* metro_graph.c - adjacency-list graph built on the linked list (pure C). */
#include <stdlib.h>
#include <string.h>
#include "metro_graph.h"

#define INITIAL_STATION_CAPACITY 16

/* One vertex of the graph. */
typedef struct Station {
    char name[MG_MAX_NAME_LEN];   /* fixed buffer: no separate free() needed */
    LinkedList adjacency;         /* outgoing connections                    */
} Station;

struct MetroGraph {
    Station *stations;   /* dynamic array, grown with realloc()  */
    int count;           /* stations in use                      */
    int capacity;        /* slots allocated                      */
    int edge_count;      /* undirected connections               */
};

/* ---- small helpers ------------------------------------------------------ */

/* Lower-case a character without depending on the locale. */
static char to_lower_ascii(char c)
{
    return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c;
}

/* Returns 1 if both strings are equal ignoring ASCII case. */
static int equal_ignore_case(const char *a, const char *b)
{
    while (*a != '\0' && *b != '\0') {
        if (to_lower_ascii(*a) != to_lower_ascii(*b)) return 0;
        a++;
        b++;
    }
    return *a == *b;   /* both must have reached the terminator */
}

/* A name is valid if it has 1..MG_MAX_NAME_LEN-1 chars and is not all spaces. */
static int is_valid_name(const char *name)
{
    size_t len, i;
    int has_visible = 0;

    if (name == NULL) return 0;
    len = strlen(name);
    if (len == 0 || len >= MG_MAX_NAME_LEN) return 0;

    for (i = 0; i < len; i++) {
        if (name[i] != ' ' && name[i] != '\t') has_visible = 1;
    }
    return has_visible;
}

static int is_valid_id(const MetroGraph *g, int id)
{
    return (g != NULL && id >= 0 && id < g->count);
}

/* ---- public API --------------------------------------------------------- */

MetroGraph *mg_create(void)
{
    /* calloc zero-fills: stations = NULL, count = capacity = edge_count = 0 */
    return (MetroGraph *)calloc(1, sizeof(MetroGraph));
}

void mg_destroy(MetroGraph *graph)
{
    int i;

    if (graph == NULL) return;

    for (i = 0; i < graph->count; i++) {
        ll_clear(&graph->stations[i].adjacency);   /* free every list node */
    }
    free(graph->stations);                         /* free the station array */
    free(graph);
}

int mg_add_station(MetroGraph *graph, const char *name)
{
    Station *station;

    if (graph == NULL || name == NULL) return MG_ERR_NULL;
    if (!is_valid_name(name)) return MG_ERR_INVALID_ARG;
    if (mg_find_station(graph, name) != -1) return MG_ERR_DUPLICATE;

    /* Grow the array when it is full. Keep the old pointer until realloc
     * succeeds, otherwise a failure would leak the existing data. */
    if (graph->count == graph->capacity) {
        int new_capacity = (graph->capacity == 0) ? INITIAL_STATION_CAPACITY
                                                  : graph->capacity * 2;
        Station *bigger = (Station *)realloc(graph->stations,
                                             (size_t)new_capacity * sizeof(Station));
        if (bigger == NULL) return MG_ERR_NOMEM;
        graph->stations = bigger;
        graph->capacity = new_capacity;
    }

    station = &graph->stations[graph->count];
    strcpy(station->name, name);          /* length already checked above */
    ll_init(&station->adjacency);

    graph->count++;
    return graph->count - 1;              /* the new station's id */
}

int mg_add_connection(MetroGraph *graph, int id_a, int id_b, int travel_time)
{
    if (graph == NULL) return MG_ERR_NULL;
    if (!is_valid_id(graph, id_a) || !is_valid_id(graph, id_b)) return MG_ERR_INVALID_ID;
    if (id_a == id_b || travel_time <= 0) return MG_ERR_INVALID_ARG;
    if (ll_contains(&graph->stations[id_a].adjacency, id_b)) return MG_ERR_DUPLICATE;

    if (ll_append(&graph->stations[id_a].adjacency, id_b, travel_time) != 0) {
        return MG_ERR_NOMEM;
    }
    if (ll_append(&graph->stations[id_b].adjacency, id_a, travel_time) != 0) {
        /* Undo the first half so the graph never holds a one-way edge. */
        ll_remove(&graph->stations[id_a].adjacency, id_b);
        return MG_ERR_NOMEM;
    }

    graph->edge_count++;
    return MG_OK;
}

int mg_station_count(const MetroGraph *graph)
{
    return (graph == NULL) ? 0 : graph->count;
}

int mg_connection_count(const MetroGraph *graph)
{
    return (graph == NULL) ? 0 : graph->edge_count;
}

const char *mg_station_name(const MetroGraph *graph, int id)
{
    if (!is_valid_id(graph, id)) return NULL;
    return graph->stations[id].name;
}

int mg_find_station(const MetroGraph *graph, const char *name)
{
    int i;

    if (graph == NULL || name == NULL) return -1;
    for (i = 0; i < graph->count; i++) {         /* linear search: O(V) */
        if (equal_ignore_case(graph->stations[i].name, name)) return i;
    }
    return -1;
}

const LinkedList *mg_neighbors(const MetroGraph *graph, int id)
{
    if (!is_valid_id(graph, id)) return NULL;
    return &graph->stations[id].adjacency;
}

const char *mg_status_message(int status)
{
    switch (status) {
        case MG_OK:              return "success";
        case MG_ERR_NULL:        return "null pointer";
        case MG_ERR_NOMEM:       return "out of memory";
        case MG_ERR_INVALID_ID:  return "invalid station id";
        case MG_ERR_INVALID_ARG: return "invalid argument";
        case MG_ERR_DUPLICATE:   return "already exists";
        default:                 return "unknown error";
    }
}
