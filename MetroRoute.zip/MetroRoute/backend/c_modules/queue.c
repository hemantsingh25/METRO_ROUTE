/* queue.c - circular-array queue of ints (pure C). */
#include <stdlib.h>
#include <limits.h>
#include "queue.h"

#define QUEUE_DEFAULT_CAPACITY 8

int queue_init(Queue *q, int initial_capacity)
{
    if (q == NULL) return -1;
    if (initial_capacity <= 0) initial_capacity = QUEUE_DEFAULT_CAPACITY;

    q->data = (int *)malloc((size_t)initial_capacity * sizeof(int));
    q->capacity = 0;
    q->front = 0;
    q->count = 0;
    if (q->data == NULL) return -1;

    q->capacity = initial_capacity;
    return 0;
}

/* Double the capacity. Only called when the queue is completely full. */
static int queue_grow(Queue *q)
{
    int new_capacity;
    int *bigger;

    if (q->capacity > INT_MAX / 2) return -1;      /* would overflow */
    new_capacity = q->capacity * 2;

    bigger = (int *)realloc(q->data, (size_t)new_capacity * sizeof(int));
    if (bigger == NULL) return -1;                 /* old buffer still valid */
    q->data = bigger;

    /* If the elements wrap around the end of the old buffer, the wrapped part
     * is data[0 .. front-1]. Move it right after the old end so the elements
     * are contiguous again: front, front+1, ..., capacity-1, capacity, ... */
    if (q->front > 0) {
        int i;
        for (i = 0; i < q->front; i++) {
            q->data[q->capacity + i] = q->data[i];
        }
    }
    q->capacity = new_capacity;
    return 0;
}

int queue_enqueue(Queue *q, int value)
{
    int back;

    if (q == NULL || q->data == NULL) return -1;

    if (q->count == q->capacity) {
        if (queue_grow(q) != 0) return -1;
    }

    back = (q->front + q->count) % q->capacity;
    q->data[back] = value;
    q->count++;
    return 0;
}

int queue_dequeue(Queue *q, int *out)
{
    if (q == NULL || out == NULL || q->count == 0) return -1;

    *out = q->data[q->front];
    q->front = (q->front + 1) % q->capacity;
    q->count--;
    return 0;
}

int queue_is_empty(const Queue *q)
{
    return (q == NULL || q->count == 0);
}

int queue_size(const Queue *q)
{
    return (q == NULL) ? 0 : q->count;
}

void queue_destroy(Queue *q)
{
    if (q == NULL) return;
    free(q->data);
    q->data = NULL;
    q->capacity = 0;
    q->front = 0;
    q->count = 0;
}
