/*
 * shortest_path.h - Route-finding algorithms on the metro graph (pure C).
 *
 *   sp_dijkstra()       minimum TRAVEL TIME  (uses a binary min-heap)
 *   sp_fewest_stops()   minimum NUMBER OF STOPS (Breadth-First Search, uses
 *                       the Queue from queue.h)
 *
 * Both fill a PathResult that OWNS a heap-allocated array. The caller must
 * release it with sp_free_result() (also safe after a failed search).
 */
#ifndef SHORTEST_PATH_H
#define SHORTEST_PATH_H

#include "metro_graph.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum SpStatus {
    SP_OK = 0,
    SP_ERR_NULL = -1,              /* graph or result pointer was NULL     */
    SP_ERR_INVALID_STATION = -2,   /* source/destination id out of range   */
    SP_ERR_NO_PATH = -3,           /* destination cannot be reached        */
    SP_ERR_NOMEM = -4              /* memory allocation failed             */
} SpStatus;

typedef struct PathResult {
    int *stations;     /* station ids from source to destination, in order */
    int length;        /* number of ids in 'stations' (stops + 1)          */
    int total_time;    /* total travel time in minutes                     */
} PathResult;

/* Cheapest route by travel time (Dijkstra). O((V + E) log V).
 * If source == destination the result is that single station with time 0.
 * On any error *result is reset to "empty" (stations == NULL, length == 0). */
int sp_dijkstra(const MetroGraph *graph, int source, int destination,
                PathResult *result);

/* Route with the fewest connections (BFS). O(V + E).
 * If several routes have the same (smallest) number of stops, the one with the
 * least travel time is returned. total_time is the time of the returned route. */
int sp_fewest_stops(const MetroGraph *graph, int source, int destination,
                    PathResult *result);

/* Free the array inside a PathResult and reset it. NULL-safe, idempotent. */
void sp_free_result(PathResult *result);

/* Human-readable text for an SpStatus value (never NULL). */
const char *sp_status_message(int status);

#ifdef __cplusplus
}
#endif

#endif /* SHORTEST_PATH_H */
