/* linked_list.c - implementation of the singly linked list (pure C). */
#include <stdlib.h>
#include "linked_list.h"

void ll_init(LinkedList *list)
{
    if (list == NULL) return;
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
}

int ll_append(LinkedList *list, int destination, int travel_time)
{
    ListNode *node;

    if (list == NULL) return -1;

    node = (ListNode *)malloc(sizeof(ListNode));
    if (node == NULL) return -1;           /* out of memory: list unchanged */

    node->destination = destination;
    node->travel_time = travel_time;
    node->next = NULL;

    if (list->tail == NULL) {              /* list was empty */
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
    list->size++;
    return 0;
}

int ll_contains(const LinkedList *list, int destination)
{
    const ListNode *cur;

    if (list == NULL) return 0;
    for (cur = list->head; cur != NULL; cur = cur->next) {
        if (cur->destination == destination) return 1;
    }
    return 0;
}

int ll_remove(LinkedList *list, int destination)
{
    ListNode *prev = NULL;
    ListNode *cur;

    if (list == NULL) return 0;

    for (cur = list->head; cur != NULL; prev = cur, cur = cur->next) {
        if (cur->destination == destination) {
            if (prev == NULL) list->head = cur->next;   /* removing the head */
            else              prev->next = cur->next;

            if (cur == list->tail) list->tail = prev;   /* removing the tail */

            free(cur);
            list->size--;
            return 1;
        }
    }
    return 0;
}

void ll_clear(LinkedList *list)
{
    ListNode *cur;
    ListNode *next;

    if (list == NULL) return;

    cur = list->head;
    while (cur != NULL) {
        next = cur->next;      /* remember next BEFORE freeing the node */
        free(cur);
        cur = next;
    }
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
}
