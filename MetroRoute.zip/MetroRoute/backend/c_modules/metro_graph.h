/*
 * metro_graph.h - Weighted, undirected graph of metro stations (pure C).
 *
 *   vertex = station          (identified by an integer id 0 .. count-1)
 *   edge   = metro connection (weight = travel time in minutes)
 *
 * The graph uses an ADJACENCY LIST: every station has its own LinkedList of
 * outgoing connections (see linked_list.h). The structure is OPAQUE: callers
 * only hold a pointer and use the functions below, so the internal layout can
 * change without breaking the C++ code.
 *
 * Every function that takes a graph pointer is NULL-safe.
 */
#ifndef METRO_GRAPH_H
#define METRO_GRAPH_H

#include "linked_list.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Longest allowed station name, including the terminating '\0'. */
#define MG_MAX_NAME_LEN 64

/* Result codes. Success is 0 (or an id >= 0 for mg_add_station). */
typedef enum MgStatus {
    MG_OK = 0,
    MG_ERR_NULL = -1,          /* a required pointer was NULL           */
    MG_ERR_NOMEM = -2,         /* malloc/realloc/calloc failed          */
    MG_ERR_INVALID_ID = -3,    /* station id out of range               */
    MG_ERR_INVALID_ARG = -4,   /* bad name, bad time, self-loop, ...    */
    MG_ERR_DUPLICATE = -5      /* station or connection already exists  */
} MgStatus;

typedef struct MetroGraph MetroGraph;   /* opaque type */

/* Create an empty graph. Returns NULL if memory is exhausted. */
MetroGraph *mg_create(void);

/* Free the graph, all station records and all connection nodes.
 * Passing NULL is allowed. The pointer must not be used afterwards. */
void mg_destroy(MetroGraph *graph);

/* Add a station. Names are unique, compared ignoring upper/lower case.
 * Returns the new station id (>= 0) or a negative MgStatus. */
int mg_add_station(MetroGraph *graph, const char *name);

/* Add a bidirectional connection between two station ids.
 * 'travel_time' must be > 0, the two ids must differ, and the connection must
 * not already exist. Returns MG_OK or a negative MgStatus. If memory runs out
 * half-way the graph is left exactly as it was before the call. */
int mg_add_connection(MetroGraph *graph, int id_a, int id_b, int travel_time);

/* Number of stations / number of (undirected) connections. */
int mg_station_count(const MetroGraph *graph);
int mg_connection_count(const MetroGraph *graph);

/* Name of a station, or NULL for an invalid id. The returned string belongs to
 * the graph: do not free or modify it, and do not use it after mg_destroy(). */
const char *mg_station_name(const MetroGraph *graph, int id);

/* Station id for a name (case-insensitive), or -1 if there is no such station. */
int mg_find_station(const MetroGraph *graph, const char *name);

/* Adjacency list of a station (read-only), or NULL for an invalid id.
 * Walk it with:  for (n = list->head; n != NULL; n = n->next) ...           */
const LinkedList *mg_neighbors(const MetroGraph *graph, int id);

/* Human-readable text for a MgStatus value (never NULL). */
const char *mg_status_message(int status);

#ifdef __cplusplus
}
#endif

#endif /* METRO_GRAPH_H */
