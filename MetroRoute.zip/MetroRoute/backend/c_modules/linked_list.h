/*
 * linked_list.h - Singly linked list used as the ADJACENCY LIST of one station.
 *
 * Every station owns one LinkedList. Each node of that list is one outgoing
 * metro connection: "you can travel to station <destination> in <travel_time>
 * minutes".
 *
 * Pure C (C11). Usable from C++ because of the extern "C" guards.
 */
#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#ifdef __cplusplus
extern "C" {
#endif

/* One node = one connection (an edge of the metro graph). */
typedef struct ListNode {
    int destination;          /* id of the station at the other end        */
    int travel_time;          /* minutes needed to travel along this edge  */
    struct ListNode *next;    /* next connection of the same station       */
} ListNode;

/* The list itself. 'tail' makes appending O(1) and keeps insertion order. */
typedef struct LinkedList {
    ListNode *head;
    ListNode *tail;
    int size;
} LinkedList;

/* Make an empty list. Must be called once before any other function. */
void ll_init(LinkedList *list);

/* Append a connection at the end (O(1)).
 * Returns 0 on success, -1 if list is NULL or memory could not be allocated. */
int ll_append(LinkedList *list, int destination, int travel_time);

/* Returns 1 if a connection to 'destination' exists, otherwise 0. (O(n)) */
int ll_contains(const LinkedList *list, int destination);

/* Remove the first connection that leads to 'destination'.
 * Returns 1 if a node was removed, 0 if none was found. (O(n)) */
int ll_remove(LinkedList *list, int destination);

/* Free every node and leave the list empty (safe to call twice). */
void ll_clear(LinkedList *list);

#ifdef __cplusplus
}
#endif

#endif /* LINKED_LIST_H */
