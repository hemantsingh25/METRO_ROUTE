// metro_route_app.hpp - MetroRouteApp: menu and user interaction.
//
// Owns the MetroNetwork (data) and the RoutePlanner (logic). main() only has to
// create one MetroRouteApp and call run().
#ifndef METRO_ROUTE_APP_HPP
#define METRO_ROUTE_APP_HPP

#include <string>
#include "metro_network.hpp"
#include "route_planner.hpp"

class MetroRouteApp {
private:
    // Declaration order matters: network_ must be created before planner_,
    // because the planner keeps a reference to the network.
    MetroNetwork network_;
    RoutePlanner planner_;

    void loadDefaultNetwork();

    void showMenu() const;
    void viewAllStations() const;
    void viewNetwork() const;
    void findRoute(bool fewestStops);
    void printResult(const RouteResult& result, const std::string& source,
                     const std::string& destination) const;

    // Input helpers: both return false when the input stream has ended.
    static bool readLine(std::string& line);
    static bool readChoice(int& choice);   // choice = -1 if not a valid number

public:
    MetroRouteApp();
    void run();   // main menu loop
};

#endif
