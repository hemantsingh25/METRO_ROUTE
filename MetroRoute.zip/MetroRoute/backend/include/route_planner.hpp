// route_planner.hpp - route finding with interchangeable strategies.
//
// INHERITANCE  : FastestRouteStrategy and FewestStopsStrategy derive from the
//                abstract base class RouteStrategy.
// POLYMORPHISM : RoutePlanner holds a RouteStrategy pointer and calls
//                findRoute(); the version that runs (Dijkstra or BFS) is
//                chosen at RUN TIME by the object the pointer refers to.
// ABSTRACTION  : callers never see the C functions or PathResult.
#ifndef ROUTE_PLANNER_HPP
#define ROUTE_PLANNER_HPP

#include <memory>
#include <string>
#include <vector>
#include "metro_network.hpp"

// Outcome of a route search.
enum class RouteStatus {
    Found,
    SameStation,
    SourceNotFound,
    DestinationNotFound,
    NoRoute,
    Error
};

// Immutable result of a route search (private data, public getters).
class RouteResult {
private:
    RouteStatus status_;
    std::string strategyName_;
    std::vector<int> stationIds_;   // in travel order
    int totalTime_;

public:
    RouteResult();
    RouteResult(RouteStatus status, const std::string& strategyName,
                const std::vector<int>& stationIds = std::vector<int>(),
                int totalTime = 0);

    RouteStatus getStatus() const;
    bool isFound() const;
    const std::string& getStrategyName() const;
    const std::vector<int>& getStationIds() const;
    int getTotalTime() const;   // minutes
    int getStopCount() const;   // number of connections travelled
};

// Abstract base class: the "interface" every route-finding method must follow.
class RouteStrategy {
public:
    virtual ~RouteStrategy() {}   // virtual: deleting through the base is safe

    virtual std::string getName() const = 0;
    virtual RouteResult findRoute(const MetroNetwork& network,
                                  int sourceId, int destinationId) const = 0;
};

// Minimum travel time -> calls the C function sp_dijkstra().
class FastestRouteStrategy : public RouteStrategy {
public:
    std::string getName() const override;
    RouteResult findRoute(const MetroNetwork& network,
                          int sourceId, int destinationId) const override;
};

// Minimum number of stops -> calls the C function sp_fewest_stops() (BFS).
class FewestStopsStrategy : public RouteStrategy {
public:
    std::string getName() const override;
    RouteResult findRoute(const MetroNetwork& network,
                          int sourceId, int destinationId) const override;
};

// Validates station names, then delegates to the current strategy.
class RoutePlanner {
private:
    const MetroNetwork& network_;
    std::unique_ptr<RouteStrategy> strategy_;   // owned; freed automatically

public:
    explicit RoutePlanner(const MetroNetwork& network);

    // Replace the strategy (the planner takes ownership). NULL is ignored.
    void setStrategy(std::unique_ptr<RouteStrategy> strategy);
    std::string getStrategyName() const;

    RouteResult planRoute(const std::string& source,
                          const std::string& destination) const;
};

#endif
