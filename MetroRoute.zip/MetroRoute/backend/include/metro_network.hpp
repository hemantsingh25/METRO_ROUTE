// metro_network.hpp - MetroNetwork: C++ wrapper (RAII) around the C graph.
//
// ABSTRACTION : the rest of the program sees names, std::string and exceptions;
//               the C pointers and error codes stay hidden in here.
// ENCAPSULATION: the only data member is a private pointer to the C graph.
// OWNERSHIP   : the constructor creates the C graph (mg_create) and the
//               destructor frees it (mg_destroy). Copying is forbidden (it
//               would free the same graph twice); moving is allowed.
#ifndef METRO_NETWORK_HPP
#define METRO_NETWORK_HPP

#include <string>
#include <vector>
#include "metro_station.h"
#include "../c_modules/metro_graph.h"

class MetroNetwork {
private:
    MetroGraph* graph_;   // owned C object, NULL only after being moved from

public:
    MetroNetwork();                                  // throws std::bad_alloc
    ~MetroNetwork();

    MetroNetwork(const MetroNetwork&) = delete;      // no copies: single owner
    MetroNetwork& operator=(const MetroNetwork&) = delete;
    MetroNetwork(MetroNetwork&& other) noexcept;     // ownership transfer
    MetroNetwork& operator=(MetroNetwork&& other) noexcept;

    // Build the network.
    // Both throw std::invalid_argument for bad input and std::runtime_error
    // for other failures (e.g. out of memory).
    int addStation(const std::string& name);         // returns the new id
    void addConnection(const std::string& station1,
                       const std::string& station2, int travelTime);

    // Queries
    int getStationCount() const;
    int getConnectionCount() const;
    bool stationExists(const std::string& name) const;
    int getStationId(const std::string& name) const;         // -1 if unknown
    std::string getStationName(int stationId) const;         // "" if invalid
    MetroStation getStation(int stationId) const;            // throws std::out_of_range
    std::vector<MetroStation> getAllStations() const;

    // Read-only access to the C graph, needed by the route-finding strategies
    // (they call the C algorithms). Callers must never free this pointer.
    const MetroGraph* cGraph() const;
};

#endif
