// metro_station.h - MetroStation: a read-only description of one station.
//
// A MetroStation is a small VALUE object. MetroNetwork creates it from the
// data stored in the C graph, so the C++ code can work with std::string and
// std::vector without ever touching the raw C pointers.
#ifndef METRO_STATION_H
#define METRO_STATION_H

#include <string>
#include <vector>

// A connection from one station to a neighbouring station.
struct Connection {
    int destinationId;
    int travelTime;  // in minutes

    Connection(int dest, int time) : destinationId(dest), travelTime(time) {}
};

class MetroStation {
private:
    int id_;
    std::string name_;
    std::vector<Connection> connections_;

public:
    MetroStation();
    MetroStation(int stationId, const std::string& stationName);

    // Getters
    int getId() const;
    const std::string& getName() const;
    const std::vector<Connection>& getConnections() const;
    int getConnectionCount() const;

    // Add a connection to another station (ignores invalid values)
    void addConnection(int destinationId, int travelTime);
};

#endif
