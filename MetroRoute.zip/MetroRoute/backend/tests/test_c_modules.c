/*
 * test_c_modules.c - automated tests for the C data structures and algorithms.
 * Pure C: linked list, queue, graph, Dijkstra and BFS.
 * Exit code 0 = all tests passed.
 */
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include "../c_modules/linked_list.h"
#include "../c_modules/queue.h"
#include "../c_modules/metro_graph.h"
#include "../c_modules/shortest_path.h"

static int g_checks = 0;
static int g_failed = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        g_checks++;                                                          \
        if (!(cond)) {                                                       \
            g_failed++;                                                      \
            printf("    FAILED: %s  (line %d)\n", #cond, __LINE__);          \
        }                                                                    \
    } while (0)

static void run(const char *name, void (*test)(void))
{
    int failed_before = g_failed;
    test();
    printf("[%s] %s\n", (g_failed == failed_before) ? "PASS" : "FAIL", name);
}

/* ---- the original MetroRoute network (20 stations, 21 connections) ------ */
static const char *STATIONS[20] = {
    "Prem Nagar", "ISBT", "Clock Tower", "Rajpur Road", "EC Road",
    "Race Course", "Ballupur", "Patel Nagar", "Clement Town", "Sahastradhara",
    "Jogiwala", "Mussoorie Diversion", "Selaqui", "Herbertpur", "Vikasnagar",
    "Rajaji National Park", "Dehradun Railway Station", "Rispana",
    "Hathibarkala", "Premnagar Chowk"
};

static const struct { const char *a; const char *b; int t; } LINKS[21] = {
    {"Prem Nagar", "ISBT", 5}, {"ISBT", "Clock Tower", 4},
    {"Clock Tower", "Rajpur Road", 3}, {"Rajpur Road", "EC Road", 6},
    {"EC Road", "Race Course", 4}, {"Race Course", "Ballupur", 5},
    {"Ballupur", "Mussoorie Diversion", 7},
    {"Rajpur Road", "Patel Nagar", 7}, {"Patel Nagar", "Clement Town", 5},
    {"Clement Town", "Sahastradhara", 8},
    {"Sahastradhara", "Rajaji National Park", 10},
    {"Clock Tower", "Jogiwala", 6}, {"Jogiwala", "Rispana", 5},
    {"Rispana", "Hathibarkala", 4},
    {"ISBT", "Dehradun Railway Station", 3},
    {"Dehradun Railway Station", "Premnagar Chowk", 4},
    {"Premnagar Chowk", "Selaqui", 9}, {"Selaqui", "Herbertpur", 12},
    {"Herbertpur", "Vikasnagar", 8},
    {"Prem Nagar", "Premnagar Chowk", 2}, {"EC Road", "Clement Town", 9}
};

static MetroGraph *build_metro(void)
{
    int i;
    MetroGraph *g = mg_create();
    if (g == NULL) return NULL;
    for (i = 0; i < 20; i++) mg_add_station(g, STATIONS[i]);
    for (i = 0; i < 21; i++) {
        mg_add_connection(g, mg_find_station(g, LINKS[i].a),
                          mg_find_station(g, LINKS[i].b), LINKS[i].t);
    }
    return g;
}

/* ---- linked list --------------------------------------------------------- */
static void test_linked_list(void)
{
    LinkedList list;
    const ListNode *n;

    ll_init(&list);
    CHECK(list.size == 0 && list.head == NULL && list.tail == NULL);

    CHECK(ll_append(&list, 10, 1) == 0);
    CHECK(ll_append(&list, 20, 2) == 0);
    CHECK(ll_append(&list, 30, 3) == 0);
    CHECK(list.size == 3);

    /* insertion order is preserved */
    n = list.head;
    CHECK(n->destination == 10 && n->travel_time == 1);
    n = n->next;
    CHECK(n->destination == 20 && n->travel_time == 2);
    n = n->next;
    CHECK(n->destination == 30 && n->next == NULL);

    CHECK(ll_contains(&list, 20) == 1);
    CHECK(ll_contains(&list, 99) == 0);

    CHECK(ll_remove(&list, 20) == 1);          /* middle */
    CHECK(list.size == 2 && ll_contains(&list, 20) == 0);
    CHECK(ll_remove(&list, 30) == 1);          /* tail   */
    CHECK(list.tail == list.head && list.tail->destination == 10);
    CHECK(ll_append(&list, 40, 4) == 0);       /* tail still valid */
    CHECK(list.head->next->destination == 40);
    CHECK(ll_remove(&list, 10) == 1);          /* head   */
    CHECK(list.head->destination == 40);
    CHECK(ll_remove(&list, 99) == 0);          /* absent */

    ll_clear(&list);
    CHECK(list.size == 0 && list.head == NULL && list.tail == NULL);
    ll_clear(&list);                           /* second clear is harmless */

    /* NULL safety */
    CHECK(ll_append(NULL, 1, 1) == -1);
    CHECK(ll_contains(NULL, 1) == 0);
    CHECK(ll_remove(NULL, 1) == 0);
    ll_clear(NULL);
    ll_init(NULL);
}

/* ---- queue --------------------------------------------------------------- */
static void test_queue(void)
{
    Queue q;
    int v = -1;
    int i;

    CHECK(queue_init(&q, 2) == 0);
    CHECK(queue_is_empty(&q) && queue_size(&q) == 0);
    CHECK(queue_dequeue(&q, &v) == -1);        /* dequeue from empty */

    CHECK(queue_enqueue(&q, 1) == 0);
    CHECK(queue_enqueue(&q, 2) == 0);
    CHECK(queue_size(&q) == 2 && !queue_is_empty(&q));
    CHECK(queue_dequeue(&q, &v) == 0 && v == 1);   /* FIFO order */

    /* front != 0 and the buffer is about to wrap, then grow while wrapped */
    CHECK(queue_enqueue(&q, 3) == 0);          /* wraps around     */
    CHECK(queue_enqueue(&q, 4) == 0);          /* full -> realloc  */
    CHECK(queue_enqueue(&q, 5) == 0);
    CHECK(q.capacity >= 4);
    for (i = 2; i <= 5; i++) {
        CHECK(queue_dequeue(&q, &v) == 0 && v == i);
    }
    CHECK(queue_is_empty(&q));

    /* many elements: stress growth + order */
    for (i = 0; i < 1000; i++) CHECK(queue_enqueue(&q, i) == 0);
    for (i = 0; i < 500; i++) { queue_dequeue(&q, &v); }
    for (i = 1000; i < 1500; i++) CHECK(queue_enqueue(&q, i) == 0);
    for (i = 500; i < 1500; i++) {
        CHECK(queue_dequeue(&q, &v) == 0 && v == i);
    }
    CHECK(queue_is_empty(&q));

    queue_destroy(&q);
    CHECK(q.data == NULL);
    queue_destroy(&q);                         /* double destroy is harmless */

    CHECK(queue_init(&q, 0) == 0 && q.capacity > 0);   /* default capacity */
    queue_destroy(&q);

    CHECK(queue_init(NULL, 4) == -1);
    CHECK(queue_enqueue(NULL, 1) == -1);
    CHECK(queue_dequeue(NULL, &v) == -1);
    CHECK(queue_is_empty(NULL) == 1 && queue_size(NULL) == 0);
    queue_destroy(NULL);
}

/* ---- graph --------------------------------------------------------------- */
static void test_graph(void)
{
    MetroGraph *g = mg_create();
    const LinkedList *adj;
    int a, b, c, i;
    char longname[MG_MAX_NAME_LEN + 10];

    CHECK(g != NULL);
    CHECK(mg_station_count(g) == 0 && mg_connection_count(g) == 0);

    a = mg_add_station(g, "Alpha");
    b = mg_add_station(g, "Beta");
    c = mg_add_station(g, "Gamma");
    CHECK(a == 0 && b == 1 && c == 2);
    CHECK(mg_station_count(g) == 3);
    CHECK(strcmp(mg_station_name(g, b), "Beta") == 0);
    CHECK(mg_station_name(g, 3) == NULL && mg_station_name(g, -1) == NULL);

    /* lookup ignores case; unknown names give -1 */
    CHECK(mg_find_station(g, "gAmMa") == c);
    CHECK(mg_find_station(g, "Delta") == -1);
    CHECK(mg_find_station(g, "") == -1);
    CHECK(mg_find_station(g, NULL) == -1);

    /* invalid / duplicate stations */
    CHECK(mg_add_station(g, "alpha") == MG_ERR_DUPLICATE);
    CHECK(mg_add_station(g, "") == MG_ERR_INVALID_ARG);
    CHECK(mg_add_station(g, "   ") == MG_ERR_INVALID_ARG);
    CHECK(mg_add_station(g, NULL) == MG_ERR_NULL);
    memset(longname, 'x', sizeof(longname) - 1);
    longname[sizeof(longname) - 1] = '\0';
    CHECK(mg_add_station(g, longname) == MG_ERR_INVALID_ARG);
    CHECK(mg_station_count(g) == 3);

    /* connections are bidirectional and stored in adjacency lists */
    CHECK(mg_add_connection(g, a, b, 7) == MG_OK);
    CHECK(mg_connection_count(g) == 1);
    adj = mg_neighbors(g, a);
    CHECK(adj->size == 1 && adj->head->destination == b && adj->head->travel_time == 7);
    adj = mg_neighbors(g, b);
    CHECK(adj->size == 1 && adj->head->destination == a && adj->head->travel_time == 7);
    CHECK(mg_neighbors(g, c)->size == 0);

    /* rejected connections must not change the graph */
    CHECK(mg_add_connection(g, a, b, 9) == MG_ERR_DUPLICATE);
    CHECK(mg_add_connection(g, b, a, 9) == MG_ERR_DUPLICATE);
    CHECK(mg_add_connection(g, a, a, 3) == MG_ERR_INVALID_ARG);
    CHECK(mg_add_connection(g, a, c, 0) == MG_ERR_INVALID_ARG);
    CHECK(mg_add_connection(g, a, c, -4) == MG_ERR_INVALID_ARG);
    CHECK(mg_add_connection(g, a, 99, 3) == MG_ERR_INVALID_ID);
    CHECK(mg_add_connection(g, -1, c, 3) == MG_ERR_INVALID_ID);
    CHECK(mg_add_connection(NULL, a, c, 3) == MG_ERR_NULL);
    CHECK(mg_connection_count(g) == 1);
    CHECK(mg_neighbors(g, a)->size == 1 && mg_neighbors(g, c)->size == 0);
    CHECK(mg_neighbors(g, 50) == NULL);

    /* force the station array to grow with realloc (initial capacity is 16) */
    for (i = 0; i < 100; i++) {
        char name[32];
        sprintf(name, "Extra %d", i);
        CHECK(mg_add_station(g, name) == 3 + i);
    }
    CHECK(mg_station_count(g) == 103);
    CHECK(strcmp(mg_station_name(g, 0), "Alpha") == 0);          /* data survived */
    CHECK(mg_neighbors(g, a)->head->destination == b);           /* lists survived */
    CHECK(mg_find_station(g, "extra 99") == 102);

    /* NULL safety */
    CHECK(mg_station_count(NULL) == 0 && mg_connection_count(NULL) == 0);
    CHECK(mg_station_name(NULL, 0) == NULL && mg_neighbors(NULL, 0) == NULL);
    CHECK(mg_find_station(NULL, "x") == -1);
    CHECK(mg_add_station(NULL, "x") == MG_ERR_NULL);
    mg_destroy(NULL);

    mg_destroy(g);
}

/* ---- the real network: structure ---------------------------------------- */
static void test_metro_structure(void)
{
    MetroGraph *g = build_metro();
    CHECK(g != NULL);
    CHECK(mg_station_count(g) == 20);
    CHECK(mg_connection_count(g) == 21);
    CHECK(strcmp(mg_station_name(g, 0), "Prem Nagar") == 0);
    CHECK(strcmp(mg_station_name(g, 19), "Premnagar Chowk") == 0);
    /* ISBT has 3 neighbours: Prem Nagar, Clock Tower, Dehradun Railway Station */
    CHECK(mg_neighbors(g, mg_find_station(g, "ISBT"))->size == 3);
    mg_destroy(g);
}

/* ---- known routes -------------------------------------------------------- */
static void test_known_routes(void)
{
    MetroGraph *g = build_metro();
    PathResult r;
    int src, dst;
    static const char *expect_pn_ballupur[] = {
        "Prem Nagar", "ISBT", "Clock Tower", "Rajpur Road", "EC Road",
        "Race Course", "Ballupur"
    };
    int i;

    /* Prem Nagar -> Ballupur: same result as the original program (27 min, 6 stops) */
    src = mg_find_station(g, "Prem Nagar");
    dst = mg_find_station(g, "Ballupur");
    CHECK(sp_dijkstra(g, src, dst, &r) == SP_OK);
    CHECK(r.total_time == 27 && r.length == 7);
    for (i = 0; i < 7 && i < r.length; i++) {
        CHECK(strcmp(mg_station_name(g, r.stations[i]), expect_pn_ballupur[i]) == 0);
    }
    sp_free_result(&r);
    CHECK(r.stations == NULL && r.length == 0);

    /* Vikasnagar -> Hathibarkala: original program printed 55 min, 9 stops */
    src = mg_find_station(g, "Vikasnagar");
    dst = mg_find_station(g, "Hathibarkala");
    CHECK(sp_dijkstra(g, src, dst, &r) == SP_OK);
    CHECK(r.total_time == 55 && r.length == 10);
    CHECK(r.stations[0] == src && r.stations[r.length - 1] == dst);
    sp_free_result(&r);

    /* Neighbours: route is the direct edge */
    src = mg_find_station(g, "Prem Nagar");
    dst = mg_find_station(g, "Premnagar Chowk");
    CHECK(sp_dijkstra(g, src, dst, &r) == SP_OK);
    CHECK(r.total_time == 2 && r.length == 2);
    sp_free_result(&r);

    /* Same station: one-element path, zero time */
    CHECK(sp_dijkstra(g, src, src, &r) == SP_OK);
    CHECK(r.length == 1 && r.total_time == 0 && r.stations[0] == src);
    sp_free_result(&r);
    CHECK(sp_fewest_stops(g, src, src, &r) == SP_OK);
    CHECK(r.length == 1 && r.total_time == 0);
    sp_free_result(&r);

    mg_destroy(g);
}

/* ---- all-pairs cross-check against Floyd-Warshall ------------------------ */
static void test_all_pairs(void)
{
    MetroGraph *g = build_metro();
    static int fw_time[20][20];
    static int fw_comb[20][20];      /* hops * BIG + time: min = fewest stops, then least time */
    const int BIG = 10000;
    const int INF = INT_MAX / 4;
    int n = mg_station_count(g);
    int i, j, k;
    int pairs = 0;

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            fw_time[i][j] = (i == j) ? 0 : INF;
            fw_comb[i][j] = (i == j) ? 0 : INF;
        }
        {
            const ListNode *e;
            for (e = mg_neighbors(g, i)->head; e != NULL; e = e->next) {
                fw_time[i][e->destination] = e->travel_time;
                fw_comb[i][e->destination] = BIG + e->travel_time;
            }
        }
    }
    for (k = 0; k < n; k++)
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++) {
                if (fw_time[i][k] + fw_time[k][j] < fw_time[i][j])
                    fw_time[i][j] = fw_time[i][k] + fw_time[k][j];
                if (fw_comb[i][k] + fw_comb[k][j] < fw_comb[i][j])
                    fw_comb[i][j] = fw_comb[i][k] + fw_comb[k][j];
            }

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            PathResult dj, bf;
            int s_dj = sp_dijkstra(g, i, j, &dj);
            int s_bf = sp_fewest_stops(g, i, j, &bf);
            int p, t_dj = 0, t_bf = 0, contiguous = 1;

            pairs++;
            CHECK(s_dj == SP_OK && s_bf == SP_OK);
            if (s_dj != SP_OK || s_bf != SP_OK) continue;

            /* Dijkstra: optimal time, and the path really costs that much */
            CHECK(dj.total_time == fw_time[i][j]);
            CHECK(dj.stations[0] == i && dj.stations[dj.length - 1] == j);
            for (p = 0; p + 1 < dj.length; p++) {
                int found = 0;
                const ListNode *e;
                for (e = mg_neighbors(g, dj.stations[p])->head; e; e = e->next) {
                    if (e->destination == dj.stations[p + 1]) { t_dj += e->travel_time; found = 1; break; }
                }
                if (!found) contiguous = 0;
            }
            CHECK(contiguous && t_dj == dj.total_time);

            /* BFS: fewest stops, and among those the least time; the reported
             * time matches its own path */
            contiguous = 1;
            CHECK(bf.length - 1 == fw_comb[i][j] / BIG);
            CHECK(bf.total_time == fw_comb[i][j] % BIG);
            CHECK(bf.stations[0] == i && bf.stations[bf.length - 1] == j);
            for (p = 0; p + 1 < bf.length; p++) {
                int found = 0;
                const ListNode *e;
                for (e = mg_neighbors(g, bf.stations[p])->head; e; e = e->next) {
                    if (e->destination == bf.stations[p + 1]) { t_bf += e->travel_time; found = 1; break; }
                }
                if (!found) contiguous = 0;
            }
            CHECK(contiguous && t_bf == bf.total_time);
            CHECK(bf.total_time >= dj.total_time);   /* Dijkstra is never slower */

            sp_free_result(&dj);
            sp_free_result(&bf);
        }
    }
    CHECK(pairs == 400);    /* 20 x 20, including the 20 same-station pairs */
    mg_destroy(g);
}

/* ---- error handling: invalid ids, disconnected stations ------------------ */
static void test_errors_and_unreachable(void)
{
    MetroGraph *g = mg_create();
    PathResult r;
    int a = mg_add_station(g, "A");
    int b = mg_add_station(g, "B");
    int c = mg_add_station(g, "C");
    int d = mg_add_station(g, "Island");
    mg_add_connection(g, a, b, 4);
    mg_add_connection(g, b, c, 6);

    /* reachable */
    CHECK(sp_dijkstra(g, a, c, &r) == SP_OK && r.total_time == 10 && r.length == 3);
    sp_free_result(&r);

    /* unreachable: 'Island' has no connections */
    CHECK(sp_dijkstra(g, a, d, &r) == SP_ERR_NO_PATH);
    CHECK(r.stations == NULL && r.length == 0);
    sp_free_result(&r);                         /* safe after failure */
    CHECK(sp_fewest_stops(g, a, d, &r) == SP_ERR_NO_PATH);
    CHECK(r.stations == NULL);
    CHECK(sp_dijkstra(g, d, a, &r) == SP_ERR_NO_PATH);
    CHECK(sp_fewest_stops(g, d, a, &r) == SP_ERR_NO_PATH);
    CHECK(sp_dijkstra(g, d, d, &r) == SP_OK && r.length == 1);   /* island to itself */
    sp_free_result(&r);

    /* invalid ids */
    CHECK(sp_dijkstra(g, -1, a, &r) == SP_ERR_INVALID_STATION);
    CHECK(sp_dijkstra(g, a, 4, &r) == SP_ERR_INVALID_STATION);
    CHECK(sp_dijkstra(g, 100, 200, &r) == SP_ERR_INVALID_STATION);
    CHECK(sp_fewest_stops(g, -5, a, &r) == SP_ERR_INVALID_STATION);
    CHECK(sp_fewest_stops(g, a, 4, &r) == SP_ERR_INVALID_STATION);
    CHECK(r.stations == NULL);

    /* NULL pointers */
    CHECK(sp_dijkstra(NULL, 0, 1, &r) == SP_ERR_NULL);
    CHECK(sp_dijkstra(g, a, b, NULL) == SP_ERR_NULL);
    CHECK(sp_fewest_stops(NULL, 0, 1, &r) == SP_ERR_NULL);
    CHECK(sp_fewest_stops(g, a, b, NULL) == SP_ERR_NULL);
    sp_free_result(NULL);

    mg_destroy(g);
}

/* ---- Dijkstra and BFS can disagree (why both exist) ---------------------- */
static void test_dijkstra_vs_bfs(void)
{
    /* A-C is a direct but SLOW link (10). A-B-C is two stops but only 2 minutes. */
    MetroGraph *g = mg_create();
    PathResult fast, few;
    int a = mg_add_station(g, "A");
    int b = mg_add_station(g, "B");
    int c = mg_add_station(g, "C");
    mg_add_connection(g, a, b, 1);
    mg_add_connection(g, b, c, 1);
    mg_add_connection(g, a, c, 10);

    CHECK(sp_dijkstra(g, a, c, &fast) == SP_OK);
    CHECK(fast.total_time == 2 && fast.length == 3 && fast.stations[1] == b);

    CHECK(sp_fewest_stops(g, a, c, &few) == SP_OK);
    CHECK(few.total_time == 10 && few.length == 2);

    sp_free_result(&fast);
    sp_free_result(&few);
    mg_destroy(g);
}

/* ---- BFS tie-break: equal stops -> choose the faster route -------------- */
static void test_bfs_tie_break(void)
{
    /* S-X-T costs 20, S-Y-T costs 3: both have 2 stops. S-Z-W-T has 3 stops. */
    MetroGraph *g = mg_create();
    PathResult r;
    int s = mg_add_station(g, "S");
    int x = mg_add_station(g, "X");
    int y = mg_add_station(g, "Y");
    int t = mg_add_station(g, "T");
    mg_add_connection(g, s, x, 10);      /* X is found first (added first) */
    mg_add_connection(g, x, t, 10);
    mg_add_connection(g, s, y, 1);
    mg_add_connection(g, y, t, 2);

    CHECK(sp_fewest_stops(g, s, t, &r) == SP_OK);
    CHECK(r.length == 3 && r.total_time == 3 && r.stations[1] == y);
    sp_free_result(&r);
    mg_destroy(g);
}

/* ---- larger synthetic graph: forces heap / queue growth ------------------ */
static void test_large_chain(void)
{
    enum { N = 2000 };
    MetroGraph *g = mg_create();
    PathResult r;
    int i;

    for (i = 0; i < N; i++) {
        char name[32];
        sprintf(name, "S%d", i);
        CHECK(mg_add_station(g, name) == i);
    }
    for (i = 0; i + 1 < N; i++) CHECK(mg_add_connection(g, i, i + 1, 2) == MG_OK);
    /* Shortcuts 0-50, 50-100, ... cost 90 instead of 50 hops x 2 = 100 minutes,
     * so Dijkstra should use all 39 of them: 2*1999 - 39*10 = 3608 minutes. */
    for (i = 0; i + 50 < N; i += 50) mg_add_connection(g, i, i + 50, 90);

    CHECK(sp_dijkstra(g, 0, N - 1, &r) == SP_OK);
    CHECK(r.total_time == 2 * (N - 1) - 39 * 10);
    CHECK(r.length == 89);      /* 39 shortcut hops + 49 normal hops + 1 */
    sp_free_result(&r);
    CHECK(sp_fewest_stops(g, 0, N - 1, &r) == SP_OK);
    CHECK(r.length == (N - 1) / 50 + 1 + ((N - 1) % 50));
    sp_free_result(&r);

    mg_destroy(g);
}

int main(void)
{
    printf("=== C module tests ===\n");
    run("linked list: append/contains/remove/clear", test_linked_list);
    run("queue: FIFO order, wrap-around, growth, empty", test_queue);
    run("graph: stations, connections, validation, growth", test_graph);
    run("metro network: 20 stations / 21 connections", test_metro_structure);
    run("known routes match the original program", test_known_routes);
    run("all 400 pairs vs Floyd-Warshall (Dijkstra and BFS)", test_all_pairs);
    run("errors: invalid ids, NULL, unreachable station", test_errors_and_unreachable);
    run("Dijkstra (time) vs BFS (stops) can differ", test_dijkstra_vs_bfs);
    run("BFS tie-break: same stops -> least time", test_bfs_tie_break);
    run("2000-station chain: heap/queue growth", test_large_chain);

    printf("--- %d checks, %d failed ---\n", g_checks, g_failed);
    return (g_failed == 0) ? 0 : 1;
}
