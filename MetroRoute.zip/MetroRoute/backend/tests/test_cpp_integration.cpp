// test_cpp_integration.cpp - tests the C++ classes sitting on top of the C code.
// Exit code 0 = all tests passed.
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include "../include/metro_station.h"
#include "../include/metro_network.hpp"
#include "../include/route_planner.hpp"

static int g_checks = 0;
static int g_failed = 0;

#define CHECK(cond)                                                          \
    do {                                                                     \
        g_checks++;                                                          \
        if (!(cond)) {                                                       \
            g_failed++;                                                      \
            std::printf("    FAILED: %s  (line %d)\n", #cond, __LINE__);     \
        }                                                                    \
    } while (0)

#define CHECK_THROWS(expr, ExceptionType)                                    \
    do {                                                                     \
        g_checks++;                                                          \
        bool caught = false;                                                 \
        try { expr; } catch (const ExceptionType&) { caught = true; }        \
        if (!caught) {                                                       \
            g_failed++;                                                      \
            std::printf("    FAILED: %s did not throw %s (line %d)\n",       \
                        #expr, #ExceptionType, __LINE__);                    \
        }                                                                    \
    } while (0)

static void run(const char* name, void (*test)()) {
    int before = g_failed;
    test();
    std::printf("[%s] %s\n", (g_failed == before) ? "PASS" : "FAIL", name);
}

// Small network:  A --1-- B --1-- C   and a slow direct link A --10-- C.
// "Island" is not connected to anything.
static void buildSmall(MetroNetwork& n) {
    n.addStation("A");
    n.addStation("B");
    n.addStation("C");
    n.addStation("Island");
    n.addConnection("A", "B", 1);
    n.addConnection("B", "C", 1);
    n.addConnection("A", "C", 10);
}

static void testMetroStation() {
    MetroStation empty;
    CHECK(empty.getId() == -1 && empty.getName().empty());
    CHECK(empty.getConnectionCount() == 0);

    MetroStation s(3, "ISBT");
    s.addConnection(1, 5);
    s.addConnection(2, 4);
    s.addConnection(-1, 4);   // invalid, ignored
    s.addConnection(2, 0);    // invalid, ignored
    CHECK(s.getId() == 3 && s.getName() == "ISBT");
    CHECK(s.getConnectionCount() == 2);
    CHECK(s.getConnections()[1].destinationId == 2 && s.getConnections()[1].travelTime == 4);
}

static void testNetworkBasics() {
    MetroNetwork n;
    CHECK(n.getStationCount() == 0 && n.getConnectionCount() == 0);
    buildSmall(n);
    CHECK(n.getStationCount() == 4 && n.getConnectionCount() == 3);

    // lookups ignore case and surrounding blanks
    CHECK(n.getStationId("a") == 0);
    CHECK(n.getStationId("  Island \t") == 3);
    CHECK(n.stationExists("b") && !n.stationExists("Nowhere"));
    CHECK(n.getStationId("") == -1);
    CHECK(n.getStationName(2) == "C");
    CHECK(n.getStationName(99).empty() && n.getStationName(-1).empty());

    // getStation() copies the C adjacency list into a C++ object
    MetroStation a = n.getStation(0);
    CHECK(a.getName() == "A" && a.getConnectionCount() == 2);
    CHECK(a.getConnections()[0].destinationId == 1 && a.getConnections()[0].travelTime == 1);
    CHECK(a.getConnections()[1].destinationId == 2 && a.getConnections()[1].travelTime == 10);
    CHECK(n.getStation(3).getConnectionCount() == 0);
    CHECK_THROWS(n.getStation(4), std::out_of_range);
    CHECK_THROWS(n.getStation(-1), std::out_of_range);
    CHECK(n.getAllStations().size() == 4);
}

static void testNetworkErrors() {
    MetroNetwork n;
    buildSmall(n);
    CHECK_THROWS(n.addStation("a"), std::invalid_argument);          // duplicate
    CHECK_THROWS(n.addStation(""), std::invalid_argument);
    CHECK_THROWS(n.addStation("    "), std::invalid_argument);
    CHECK_THROWS(n.addStation(std::string(200, 'x')), std::invalid_argument);
    CHECK_THROWS(n.addConnection("A", "Nowhere", 3), std::invalid_argument);
    CHECK_THROWS(n.addConnection("A", "B", 3), std::invalid_argument);  // duplicate edge
    CHECK_THROWS(n.addConnection("A", "A", 3), std::invalid_argument);  // self loop
    CHECK_THROWS(n.addConnection("C", "Island", 0), std::invalid_argument);
    CHECK_THROWS(n.addConnection("C", "Island", -2), std::invalid_argument);
    CHECK(n.getStationCount() == 4 && n.getConnectionCount() == 3);     // unchanged
}

static void testOwnership() {
    // Move construction: the new object owns the graph, the old one is empty
    // but still safe to use and to destroy (no double free).
    MetroNetwork first;
    buildSmall(first);
    const MetroGraph* handle = first.cGraph();

    MetroNetwork second(std::move(first));
    CHECK(second.cGraph() == handle);
    CHECK(second.getStationCount() == 4);
    CHECK(first.cGraph() == NULL);
    CHECK(first.getStationCount() == 0 && first.getStationId("A") == -1);
    CHECK(first.getStationName(0).empty());

    // Move assignment: the target's old graph is released, ownership transferred.
    MetroNetwork third;
    third.addStation("Old");
    third = std::move(second);
    CHECK(third.getStationCount() == 4 && !third.stationExists("Old"));
    CHECK(second.cGraph() == NULL);

    MetroNetwork& alias = third;
    third = std::move(alias);   // self-move must not destroy the data
    CHECK(third.getStationCount() == 4);
}

static void testPlannerStatuses() {
    MetroNetwork n;
    buildSmall(n);
    RoutePlanner planner(n);

    RouteResult r = planner.planRoute("A", "C");
    CHECK(r.getStatus() == RouteStatus::Found && r.isFound());

    CHECK(planner.planRoute("Nowhere", "A").getStatus() == RouteStatus::SourceNotFound);
    CHECK(planner.planRoute("A", "Nowhere").getStatus() == RouteStatus::DestinationNotFound);
    CHECK(planner.planRoute("", "A").getStatus() == RouteStatus::SourceNotFound);
    CHECK(planner.planRoute("Nowhere", "Nowhere2").getStatus() == RouteStatus::SourceNotFound);

    RouteResult same = planner.planRoute("b", " B ");
    CHECK(same.getStatus() == RouteStatus::SameStation && !same.isFound());
    CHECK(same.getTotalTime() == 0 && same.getStopCount() == 0);

    CHECK(planner.planRoute("A", "Island").getStatus() == RouteStatus::NoRoute);
    CHECK(planner.planRoute("Island", "C").getStatus() == RouteStatus::NoRoute);

    planner.setStrategy(std::unique_ptr<RouteStrategy>(new FewestStopsStrategy()));
    CHECK(planner.planRoute("A", "Island").getStatus() == RouteStatus::NoRoute);
    CHECK(planner.planRoute("Island", "Island").getStatus() == RouteStatus::SameStation);
}

static void testPolymorphism() {
    MetroNetwork n;
    buildSmall(n);
    RoutePlanner planner(n);

    // default strategy: Dijkstra -> A,B,C in 2 minutes
    CHECK(planner.getStrategyName() == "Dijkstra's Algorithm");
    RouteResult fast = planner.planRoute("A", "C");
    CHECK(fast.getTotalTime() == 2 && fast.getStopCount() == 2);
    CHECK(fast.getStationIds() == std::vector<int>({0, 1, 2}));
    CHECK(fast.getStrategyName() == "Dijkstra's Algorithm");

    // same call, different object behind the base-class pointer -> BFS
    planner.setStrategy(std::unique_ptr<RouteStrategy>(new FewestStopsStrategy()));
    RouteResult few = planner.planRoute("A", "C");
    CHECK(few.getTotalTime() == 10 && few.getStopCount() == 1);
    CHECK(few.getStationIds() == std::vector<int>({0, 2}));
    CHECK(few.getStrategyName() == "Breadth-First Search (fewest stops)");

    // setStrategy(NULL) is ignored and keeps the current strategy
    planner.setStrategy(std::unique_ptr<RouteStrategy>());
    CHECK(planner.getStrategyName() == "Breadth-First Search (fewest stops)");

    // strategies can also be used directly through a base-class reference
    std::unique_ptr<RouteStrategy> s(new FastestRouteStrategy());
    const RouteStrategy& base = *s;
    CHECK(base.findRoute(n, 0, 2).getTotalTime() == 2);
    CHECK(base.findRoute(n, 0, 3).getStatus() == RouteStatus::NoRoute);
    CHECK(base.findRoute(n, 0, 99).getStatus() == RouteStatus::Error);   // invalid id from C layer
    CHECK(base.findRoute(n, -1, 2).getStatus() == RouteStatus::Error);
}

// The real 20-station network, built through the C++ classes.
static void testDefaultNetworkThroughCpp() {
    MetroNetwork n;
    const char* names[] = {"Prem Nagar", "ISBT", "Clock Tower", "Rajpur Road", "EC Road",
                           "Race Course", "Ballupur"};
    for (size_t i = 0; i < 7; i++) n.addStation(names[i]);
    n.addConnection("Prem Nagar", "ISBT", 5);
    n.addConnection("ISBT", "Clock Tower", 4);
    n.addConnection("Clock Tower", "Rajpur Road", 3);
    n.addConnection("Rajpur Road", "EC Road", 6);
    n.addConnection("EC Road", "Race Course", 4);
    n.addConnection("Race Course", "Ballupur", 5);

    RoutePlanner planner(n);
    RouteResult r = planner.planRoute("prem nagar", "BALLUPUR");   // case-insensitive
    CHECK(r.isFound() && r.getTotalTime() == 27 && r.getStopCount() == 6);
    CHECK(n.getStationName(r.getStationIds().front()) == "Prem Nagar");
    CHECK(n.getStationName(r.getStationIds().back()) == "Ballupur");

    // reverse direction gives the same cost (graph is undirected)
    RouteResult back = planner.planRoute("Ballupur", "Prem Nagar");
    CHECK(back.getTotalTime() == 27 && back.getStopCount() == 6);
}

static void testManyNetworks() {
    // create and destroy many networks: exercises constructor/destructor pairs
    for (int round = 0; round < 200; round++) {
        MetroNetwork n;
        buildSmall(n);
        RoutePlanner p(n);
        CHECK(p.planRoute("A", "C").isFound());
    }
}

int main() {
    std::printf("=== C++ integration tests ===\n");
    run("MetroStation: encapsulated value object", testMetroStation);
    run("MetroNetwork: C graph wrapped correctly", testNetworkBasics);
    run("MetroNetwork: errors become exceptions", testNetworkErrors);
    run("MetroNetwork: move semantics / single ownership", testOwnership);
    run("RoutePlanner: every RouteStatus", testPlannerStatuses);
    run("Polymorphism: Dijkstra vs BFS strategies", testPolymorphism);
    run("Routes computed through C++ -> C", testDefaultNetworkThroughCpp);
    run("200 create/destroy cycles", testManyNetworks);

    std::printf("--- %d checks, %d failed ---\n", g_checks, g_failed);
    return (g_failed == 0) ? 0 : 1;
}
