@echo off
REM ======================================================================
REM  MetroRoute build script for Windows (MinGW: gcc + g++)
REM
REM  Usage (run from any folder, the script finds its own location):
REM     build.bat          build metroroute.exe
REM     build.bat run      build, then start the program
REM     build.bat test     build, then compile and run the automated tests
REM     build.bat clean    delete the build folder and metroroute.exe
REM ======================================================================
setlocal
cd /d "%~dp0"

set "MODE=%~1"
if /i "%MODE%"=="clean" goto clean

REM ---- check that the compilers are available -------------------------
where gcc >nul 2>nul
if errorlevel 1 goto nocompiler
where g++ >nul 2>nul
if errorlevel 1 goto nocompiler

REM ---- settings -------------------------------------------------------
set "CFLAGS=-std=c11 -Wall -Wextra -pedantic -O2"
set "CXXFLAGS=-std=c++11 -Wall -Wextra -pedantic -O2"
set "CDIR=backend\c_modules"
set "SDIR=backend\src"
set "OUT=build"

set "C_OBJS=%OUT%\linked_list.o %OUT%\queue.o %OUT%\metro_graph.o %OUT%\shortest_path.o"
set "OOP_OBJS=%OUT%\metro_station.o %OUT%\metro_network.o %OUT%\route_planner.o"

if not exist "%OUT%" mkdir "%OUT%"

REM ---- 1. every .c file is compiled by GCC ----------------------------
echo [1/3] Compiling C modules with gcc...
gcc %CFLAGS% -c %CDIR%\linked_list.c -o %OUT%\linked_list.o
if errorlevel 1 goto fail
gcc %CFLAGS% -c %CDIR%\queue.c -o %OUT%\queue.o
if errorlevel 1 goto fail
gcc %CFLAGS% -c %CDIR%\metro_graph.c -o %OUT%\metro_graph.o
if errorlevel 1 goto fail
gcc %CFLAGS% -c %CDIR%\shortest_path.c -o %OUT%\shortest_path.o
if errorlevel 1 goto fail

REM ---- 2. every .cpp file is compiled by G++ --------------------------
echo [2/3] Compiling C++ sources with g++...
g++ %CXXFLAGS% -c %SDIR%\metro_station.cpp -o %OUT%\metro_station.o
if errorlevel 1 goto fail
g++ %CXXFLAGS% -c %SDIR%\metro_network.cpp -o %OUT%\metro_network.o
if errorlevel 1 goto fail
g++ %CXXFLAGS% -c %SDIR%\route_planner.cpp -o %OUT%\route_planner.o
if errorlevel 1 goto fail
g++ %CXXFLAGS% -c %SDIR%\metro_route_app.cpp -o %OUT%\metro_route_app.o
if errorlevel 1 goto fail
g++ %CXXFLAGS% -c backend\CLI\main.cpp -o %OUT%\main.o
if errorlevel 1 goto fail

REM ---- 3. link all object files into ONE executable (g++ adds libstdc++)
echo [3/3] Linking metroroute.exe...
g++ -o metroroute.exe %OUT%\main.o %OUT%\metro_route_app.o %OOP_OBJS% %C_OBJS%
if errorlevel 1 goto fail

echo.
echo Build successful: metroroute.exe
if /i "%MODE%"=="test" goto tests
if /i "%MODE%"=="run" goto run
goto done

:tests
echo.
echo Compiling tests...
gcc %CFLAGS% -o %OUT%\test_c_modules.exe backend\tests\test_c_modules.c %C_OBJS%
if errorlevel 1 goto fail
g++ %CXXFLAGS% -o %OUT%\test_cpp_integration.exe backend\tests\test_cpp_integration.cpp %OOP_OBJS% %C_OBJS%
if errorlevel 1 goto fail
echo.
%OUT%\test_c_modules.exe
if errorlevel 1 goto testfail
echo.
%OUT%\test_cpp_integration.exe
if errorlevel 1 goto testfail
echo.
echo ALL TESTS PASSED
goto done

:run
echo.
metroroute.exe
goto done

:clean
if exist "build" rmdir /s /q "build"
if exist "metroroute.exe" del /q "metroroute.exe"
echo Cleaned.
goto done

:nocompiler
echo ERROR: gcc/g++ not found. Install MinGW-w64 and add its "bin" folder to PATH.
echo        See COMPILATION_GUIDE.md.
endlocal
exit /b 1

:testfail
echo.
echo SOME TESTS FAILED
endlocal
exit /b 1

:fail
echo.
echo BUILD FAILED - fix the error shown above and run build.bat again.
endlocal
exit /b 1

:done
endlocal
exit /b 0
